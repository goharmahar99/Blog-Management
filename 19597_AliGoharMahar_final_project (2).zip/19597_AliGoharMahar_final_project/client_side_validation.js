
function feedback_validation(){
  var flag = true;
   var full_name = document.getElementById('fullname').value;
   var email = document.getElementById('email').value;


   var fullname_msg = document.getElementById('fullname_msg');
   var email_msg = document.getElementById('email_msg');

var name_pattern = /^[A-Z]{1}[a-z]{2,10}[' '][A-Z]{1}[a-z]{2,10}$/;
var email_pattern = /^[a-z]{2,15}\d{2,3}[@]{1}(gmail|hotmail|yahoo)[.](com|org|.net)$/;

	if(full_name == ""){
       flag = false;
       fullname_msg = "Please Insert Fullname";
	}else{
		fullname_msg = "";
		  if(!(name_pattern.test(full_name)==true)){
		  	flag = false;
             fullname_msg.innerHTML = "Fullname name must be like eg: Hamza Khan";
		  }
	}



    if(email == ""){
       flag = false;
       email_msg.innerHTML = "Please Insert Email";
    }else{
    	email_msg.innerHTML = "";
    	 if(!(email_pattern.test(email)==true)){
             flag = false;
             email_msg.innerHTML = "email must be like eg: ahmed88@gmail.com";
    	 }
    }




	if(flag === true){
          return true;
	}else{
         return false;
	}     

}           