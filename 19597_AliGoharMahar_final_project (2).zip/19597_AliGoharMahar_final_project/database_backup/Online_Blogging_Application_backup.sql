/*
SQLyog Ultimate v12.5.0 (64 bit)
MySQL - 10.4.27-MariaDB : Database - 19597_ali_gohar_mahar
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`19597_ali_gohar_mahar` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `19597_ali_gohar_mahar`;

/*Table structure for table `blog` */

DROP TABLE IF EXISTS `blog`;

CREATE TABLE `blog` (
  `blog_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `blog_title` varchar(200) DEFAULT NULL,
  `post_per_page` int(11) DEFAULT NULL,
  `blog_background_image` text DEFAULT NULL,
  `blog_status` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`blog_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `blog_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `blog` */

insert  into `blog`(`blog_id`,`user_id`,`blog_title`,`post_per_page`,`blog_background_image`,`blog_status`,`created_at`,`updated_at`) values 
(9,45,'Ray Photographer Group',3,'images/blog_image/1838546195_blog_1.jpg','Active','2024-09-25 10:53:18','2024-09-25 10:53:18'),
(10,45,'Wild Life',2,'images/blog_image/458606555_wild_life.jpeg','Active','2024-09-23 09:35:22','0000-00-00 00:00:00'),
(11,45,'Sport',2,'images/blog_image/1655446583_sport.jpg','Active','2024-09-23 09:35:30','0000-00-00 00:00:00'),
(12,45,'Beauty Of Nature',3,'images/blog_image/757636852_nature-beauty.jpg','Active','2024-09-23 09:35:42','0000-00-00 00:00:00');

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_title` varchar(100) DEFAULT NULL,
  `category_description` text DEFAULT NULL,
  `category_status` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `category` */

insert  into `category`(`category_id`,`category_title`,`category_description`,`category_status`,`created_at`,`updated_at`) values 
(10,'Cricket World Cup','The World Cup matches officially began in the year 1975 in England, with eight teams; the 6 Test playing nations England, Australia, New Zealand, West Indies, India, Pakistan along with Srilanka and East Africa. A huge success the first time round, the tournament has been taking place every four years since then, participated by major teams all over the world.\r\n\r\n','Active','2024-09-23 03:01:21','0000-00-00 00:00:00'),
(11,'Jungle life','A jungle is land covered with dense forest and tangled vegetation, usually in tropical climates. Application of the term has varied greatly during the past century.','Active','2024-09-23 03:05:44','0000-00-00 00:00:00'),
(12,'Randomly Caption Photo','Photographers capture subjects in commercial-quality photographs. Photographers use their technical expertise, creativity, and composition skills to produce and preserve images that tell a story or record an event.','Active','2024-09-25 10:06:03','2024-09-25 10:06:03');

/*Table structure for table `following_blog` */

DROP TABLE IF EXISTS `following_blog`;

CREATE TABLE `following_blog` (
  `follow_id` int(11) NOT NULL AUTO_INCREMENT,
  `follower_id` int(11) DEFAULT NULL,
  `blog_following_id` int(11) DEFAULT NULL,
  `status` enum('Followed','Unfollowed') DEFAULT 'Followed',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`follow_id`),
  KEY `blog_following_id` (`blog_following_id`),
  KEY `follower_id` (`follower_id`),
  CONSTRAINT `following_blog_ibfk_1` FOREIGN KEY (`blog_following_id`) REFERENCES `blog` (`blog_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `following_blog_ibfk_2` FOREIGN KEY (`follower_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `following_blog` */

/*Table structure for table `post` */

DROP TABLE IF EXISTS `post`;

CREATE TABLE `post` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `blog_id` int(11) DEFAULT NULL,
  `post_title` varchar(200) NOT NULL,
  `post_summary` text NOT NULL,
  `post_description` longtext NOT NULL,
  `featured_image` text DEFAULT NULL,
  `post_status` enum('Active','InActive') DEFAULT NULL,
  `is_comment_allowed` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`post_id`),
  KEY `blog_id` (`blog_id`),
  CONSTRAINT `post_ibfk_1` FOREIGN KEY (`blog_id`) REFERENCES `blog` (`blog_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post` */

insert  into `post`(`post_id`,`blog_id`,`post_title`,`post_summary`,`post_description`,`featured_image`,`post_status`,`is_comment_allowed`,`created_at`,`updated_at`) values 
(42,11,'ODI WC 2015','The 2015 World Cup was jointly hosted by Australia and New Zealand. This edition featured 14 teams and a total of 49 matches.','The ICC Cricket World Cup is an international cricket competition. It is played in the One Day International Mayank. cricket format. The event is organised by the sport&#039;s governing body, the International Cricket Council (ICC)..The 2015 World Cup was jointly hosted by Australia and New Zealand. This edition featured 14 teams and a total of 49 matches. Australia won their fifth World Cup title, defeating New Zealand in the final.','images/post_image/978753697_wc_2015.png','Active',1,'2024-09-23 10:56:34','0000-00-00 00:00:00'),
(43,10,'Hunting in jungle','hunting, sport that involves the seeking, pursuing, and killing of wild animals and birds, called game and game birds, primarily in modern times with firearms but also with bow and arrow.','hunting, sport that involves the seeking, pursuing, and killing of wild animals and birds, called game and game birds, primarily in modern times with firearms but also with bow and arrow.hunting, Pursuit of game animals, principally as sport. To early humans hunting was a necessity, and it remained so in many societies until recently. The development of agriculture made hunting less necessary as a sole life support, but game was still pursued in order to protect crops, flocks, or herds, as well as for food. Weapons now commonly used in hunting include the rifle, shotgun, and the bow and arrow, and methods include stalking, still-hunting (lying in wait), tracking, driving, and calling. Dogs are sometimes employed to track, flush, or capture prey. In Europe much of the land once hunted upon was owned by the aristocracy, and gamekeepers were employed to regulate the amount of game that could be hunted in a given area.','images/post_image/948306846_hunting.webp','Active',1,'2024-09-23 10:59:00','0000-00-00 00:00:00'),
(44,12,'Photograghy of Nature','Nature photography is a wide range of photography taken outdoors and devoted to displaying natural elements such as landscapes, wildlife, plants, and close-ups of natural scenes and textures.','Nature photography encapsulates the art of capturing the breathtaking essence of the natural world through a lens. It’s an immersive exploration of landscapes, wildlife, and elements in their unadulterated form. What is nature photography, you might ask? It’s the visual storytelling that celebrates the raw beauty and intricacies of our planet. In this blog, immerse yourself in the captivating realm of nature photography. Discover the nuances of this art form, what is nature photography, how to master nature photography, learn some new captions for nature photography, and hashtags for nature photography.','images/post_image/1333512124_jungle-beauty.jpg','Active',1,'2024-09-23 11:01:17','0000-00-00 00:00:00'),
(48,9,'Capture Stunning Photos',' Photography is the process of recording an image – a photograph – on lightsensitive film or, in the case of digital photography, via a digital electronic or magnetic memory.',' Photographers capture subjects in commercial-quality photographs. Photographers use their technical expertise, creativity, and composition skills to produce and preserve images that tell a story or record an event. Photography is the process of recording an image – a photograph – on lightsensitive film or, in the case of digital photography, via a digital electronic or magnetic memory.\r\n','images/post_image/1271833787_post_1.png','Active',1,'2024-09-25 10:43:49','2024-09-25 10:43:49'),
(49,9,'Capture Stunning Photos','Photography is the process of recording an image – a photograph – on lightsensitive film or, in the case of digital photography, via a digital electronic or magnetic memory.','Nature photography encapsulates the art of capturing the breathtaking essence of the natural world through a lens. It’s an immersive exploration of landscapes, wildlife, and elements in their unadulterated form. What is nature photography, you might ask? It’s the visual storytelling that celebrates the raw beauty and intricacies of our planet. In this blog, immerse yourself in the caPhotographers capture subjects in commercial-quality photographs. Photographers use their technical expertise, creativity, and composition skills to produce and preserve images that tell a story or record an event. Photography is the process of recording an image – a photograph – on lightsensitive film or, in the case of digital photography, via a digital electronic or magnetic memory.','images/post_image/40494158_photography_image.jpg','Active',1,'2024-09-25 10:00:58','0000-00-00 00:00:00');

/*Table structure for table `post_atachment` */

DROP TABLE IF EXISTS `post_atachment`;

CREATE TABLE `post_atachment` (
  `post_atachment_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) DEFAULT NULL,
  `post_attachment_title` varchar(200) DEFAULT NULL,
  `post_attachment_path` text DEFAULT NULL,
  `is_active` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`post_atachment_id`),
  KEY `fk1` (`post_id`),
  CONSTRAINT `fk1` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post_atachment` */

insert  into `post_atachment`(`post_atachment_id`,`post_id`,`post_attachment_title`,`post_attachment_path`,`is_active`,`created_at`,`updated_at`) values 
(20,42,'Winner Cup','images/attachment/204898939_winner.jpg','Active','2024-09-25 11:57:37','2024-09-25 11:57:37'),
(21,43,'hunting of deer','images/attachment/206424369_deer_hunting.png','Active','2024-09-25 10:42:02','2024-09-25 10:42:02'),
(22,48,'About Pic','images/attachment/1153317898_img.jpg','Active','2024-09-25 12:00:41','2024-09-25 12:00:41'),
(23,49,'About Pic','images/attachment/1594303044_photography.jpg','Active','2024-09-25 11:59:44','2024-09-25 11:59:44');

/*Table structure for table `post_category` */

DROP TABLE IF EXISTS `post_category`;

CREATE TABLE `post_category` (
  `post_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`post_category_id`),
  KEY `post_id` (`post_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `post_category_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `post_category_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post_category` */

insert  into `post_category`(`post_category_id`,`post_id`,`category_id`,`created_at`,`updated_at`) values 
(59,42,10,'2024-09-23 10:56:35','0000-00-00 00:00:00'),
(60,43,11,'2024-09-23 10:59:00','0000-00-00 00:00:00'),
(61,44,11,'2024-09-23 11:01:17','0000-00-00 00:00:00'),
(65,48,11,'2024-09-25 10:43:49','2024-09-25 10:43:49'),
(66,49,11,'2024-09-25 10:00:58','0000-00-00 00:00:00');

/*Table structure for table `post_comment` */

DROP TABLE IF EXISTS `post_comment`;

CREATE TABLE `post_comment` (
  `post_comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `is_active` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`post_comment_id`),
  KEY `user_id` (`user_id`),
  KEY `post_id` (`post_id`),
  CONSTRAINT `post_comment_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `post_comment_ibfk_2` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post_comment` */

/*Table structure for table `role` */

DROP TABLE IF EXISTS `role`;

CREATE TABLE `role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_type` varchar(50) NOT NULL,
  `is_active` enum('Active','InActive') DEFAULT 'Active',
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `role` */

insert  into `role`(`role_id`,`role_type`,`is_active`) values 
(1,'Admin','Active'),
(2,'User','Active');

/*Table structure for table `setting` */

DROP TABLE IF EXISTS `setting`;

CREATE TABLE `setting` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `setting_key` varchar(100) DEFAULT NULL,
  `setting_value` varchar(100) DEFAULT NULL,
  `setting_status` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`setting_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `setting_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `setting` */

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` text NOT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `user_image` text DEFAULT NULL,
  `address` text DEFAULT NULL,
  `is_approved` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `is_active` enum('Active','InActive') DEFAULT 'InActive',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `user` */

insert  into `user`(`user_id`,`role_id`,`first_name`,`last_name`,`email`,`password`,`gender`,`date_of_birth`,`user_image`,`address`,`is_approved`,`is_active`,`created_at`,`updated_at`) values 
(45,1,'Arham','Khan','arham99@gmail.com','Arham.12','Male','2001-10-10','images/user_image/1127040123_arham.jpeg','Hyderabad','Approved','Active','2024-09-24 11:47:39','2024-09-24 11:47:39'),
(46,2,'Bilal','Ahmed','bilal87@gmail.com','Bilal.12','Male','1999-01-01','images/user_image/2086410390_bilal.jpeg','Karachi','Approved','Active','2024-09-24 11:48:04','2024-09-24 11:48:04'),
(47,2,'Behram','Khan','behram98@gmail.com','Behram.12','Male','1998-10-10','images/user_image/152421622_behram.jpeg','Jamshoro','Approved','Active','2024-09-24 11:47:45','2024-09-24 11:47:45'),
(48,2,'Huzaifa','Rajput','huzaifa20@gmail.com','Huzaifa.12','Male','2003-02-02','images/user_image/1559761743_huzaifa.webp','Karachi','Approved','InActive','2024-09-24 11:47:22','2024-09-24 11:47:22'),
(49,2,'Shehroz','Akhtar','shehroz12@gmail.com','Shehroz.12','Male','2001-03-11','images/user_image/1893439919_shehroz.webp','Umerkot','Pending','Active','2024-09-24 11:47:51','2024-09-24 11:47:51'),
(50,2,'Sarmad','Alam','sarmad99@gmail.com','Sarmad.12','Male','1999-02-02','images/user_image/1098962079_sarmad.jpeg','Larkana','Pending','InActive','2024-09-23 09:33:25','0000-00-00 00:00:00'),
(55,2,'Kashan','Faiz','kashan99@gmail.com','Kashan.12','Male','1999-10-10','images/user_image/661206457_dummy_img_2.webp','Hyderabad','Pending','','2024-09-25 11:51:52','0000-00-00 00:00:00');

/*Table structure for table `user_feedback` */

DROP TABLE IF EXISTS `user_feedback`;

CREATE TABLE `user_feedback` (
  `feedback_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `user_email` varchar(100) DEFAULT NULL,
  `feedback` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`feedback_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_feedback_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `user_feedback` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
