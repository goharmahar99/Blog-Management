<?php 
include "require/header.php";

?>

<div class="container my-5">
	<div class="row">
	 <div class="col-md-2"></div>
	 <div class="col-md-8">
	 <h1 class="text-center text-light bg-dark bg-gradient rounded">Forget Password</h1>
	  <?php 
       if(isset($_REQUEST['msg'])){
        ?>
        <h3 class="fw-bold text-center" style="color:<?=$_REQUEST['color']?> ;"><?=$_REQUEST['msg']?></h3>
      <?php
       }
	  ?>
	 <form action="database_file/process.php" method="POST">
		
		<div class="mb-3">
		    <label  class="form-label">Email</label>
		    <input type="email" class="form-control" name="email" required>
		</div>
		<div class="mb-3">
		    <label  class="form-label">Password</label>
		    <input type="password" class="form-control" name="password" required>
		</div>
	    <div class="mb-3">
		    <label  class="form-label">Confirm Password</label>
		    <input type="password" class="form-control" name="confirm_password" required>
		</div>
		<input type="submit" name="forget_password" class="bg-primary text-light rounded border border-none fs-5" value="Change Password">
	 </form>
		<p> Click here to...! <a class="btn btn-primary text-decoration-none my-5 mx-1" href="login_form.php" role="button">Login</a></p>
		
    </div>
    <div class="col-md-2"></div>
   </div>
</div>



<?php 
include "require/footer.php";

?>