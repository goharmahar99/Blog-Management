<?php
include "require/header.php";
include "database_file/database_setting.php";
include "database_file/database_driver.php";

$obj = new database($hostname,$username,$password,$database);
?>

  <div class="container my-5">
  	<div class="row">
  		<div class="col-sm-12">
  			<div class="row">
  				<div class="col-sm-2"></div>
  				<div class="col-sm-8">

  					<div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
						  <div class="carousel-inner">
						    <div class="carousel-item active">
						      <img src="https://morethanaflower.com/wp-content/uploads/2019/07/Welcome-to-the-blog2.jpg" class="d-block w-100 rounded" style="height: 400px; box-shadow: 10px 10px 15px grey;">
						    </div>
						    <div class="carousel-item">
						      <img src="https://firstsiteguide.com/wp-content/uploads/2018/04/The-best-blogging-sites.png" class="d-block w-100 rounded" style="height: 400px; box-shadow: 10px 10px 15px grey;">
						    </div>
						    <div class="carousel-item">
						      <img src="https://janetmachuka.com/wp-content/uploads/2018/01/blog.jpg" class="d-block w-100 rounded" style="height: 400px; box-shadow: 10px 10px 15px grey;">
						    </div>
						  </div>

            </div>
   				</div>
  				<div class="col-sm-2"></div>
  				<div class="row my-5">
  					<div class="col-12">
  						<div class="border border-dark w-100 border-1"></div>
  					</div>
  				</div>
  			</div>
  		</div>
  	</div>
  </div>

  <?php
  $limit = 3;
  $page = $_GET['page']??1;
  $offset = ($page - 1)*$limit;
  $query = "SELECT * FROM post WHERE post_status = 'Active' ORDER BY post_id DESC Limit {$offset},{$limit}";
   $execute = $obj->execute_query($query);
   if($execute->num_rows > 0){

  ?>
	<div class="conatiner m-0 p-0">
	    <div class="row  my-3">
        <div class="col-sm-12">
	    	 <h1 class="text-decoration-underline fw-bold">Latest Posts</h1>
          <div class="row">
          <?php
            while($row = mysqli_fetch_assoc($execute)){
               extract($row);
          ?>
	    	   <div class="col-sm-4">
	            <div class="card my-2" style="height: 400px;">
					<img src="<?=$featured_image?>" class="card-img-top" alt="..." style="height: 180px;">
					<div class="card-body">
					<h5 class="card-title"><?=$post_title?></h5>
				    <p class="card-text text-decoration-none"><?=substr($post_summary, 0,150)?></p>
			        <a href="detail_page.php?action=see_more&current_post_id=<?=$post_id?>" class="btn btn-primary">see more</a>
					</div>

			    </div>
	           </div>
	         <?php 
            }

            ?>
      
        </div>
      </div>
  </div>
              <nav aria-label="...">
              <ul class="pagination justify-content-center pagination-lg">
          <?php
                $post_count_query = "SELECT COUNT(post_id) 'total_post' FROM post WHERE post_status = 'Active'";
                $post_count_query_execute = $obj->execute_query($post_count_query);
                if($post_count_query_execute->num_rows > 0){
                 $fetch_data = mysqli_fetch_assoc($post_count_query_execute); 
                 extract($fetch_data);
               	$total_records = $total_post;
                 $total_page = ceil($total_records/$limit);
                }
                 for($loop = 1;$loop <= $total_page; $loop++){
          ?>
             <li class="page-item"><a class="page-link" href="index.php?page=<?=$loop?>"><?=$loop?></a></li>
           <?php
            }
            ?>
             </ul>
             </nav>
 <?php 
 }else{
 	?>
    <div class="col-sm-12">
    	<h1 class="text-center">No Post Found....</h1>
    </div>
 	<?php
 } 
 ?>

	<div class="container-fluid my-3">
	    <div class="row">
	         <div class="col-sm-12" id="blog">
	         		<h1 class="fw-bold mx-5">Recent Blogs</h1>
	         </div>
	    </div>

	    <div class="row">
	    	<?php 

	     $blog_page = $_GET['blog_page']??1;
	     $offset = ($blog_page-1)*$limit;

         $query = "SELECT * FROM blog b JOIN user u on u.user_id = b.user_id WHERE b.blog_status = 'Active' ORDER BY b.blog_id DESC Limit {$offset},{$limit}";
         $execute = $obj->execute_query($query);
         if($execute->num_rows > 0){
             while($row = mysqli_fetch_assoc($execute)){
                  extract($row);
          ?>
	        <div class="col-sm-4 my-2">
			<div class="card">
				<img src="<?=$blog_background_image?>" class="card-img-top" style="height: 180px;">
			<div class="card-body">
			<h6>Blog Follower  <?php 
                   $total_follower_query = "SELECT count(fb.follower_id) 'total_follower' FROM following_blog fb WHERE blog_following_id = '{$blog_id}'";
                   $total_follower_execute = $obj->execute_query($total_follower_query);

                   if($total_follower_execute->num_rows > 0){
                       while($fetch_data = mysqli_fetch_assoc($total_follower_execute)){
                       	   extract($fetch_data);
                       	   echo $total_follower;
                       }
                   }

				?></h6>
					<h5 class="card-title">Posted By: <span><?=$first_name." ".$last_name?></span>

           <?php
            $user = $_SESSION['user']['user_id'];
			$follow_query = "SELECT * FROM following_blog WHERE follower_id = '{$user}' AND blog_following_id = '{$blog_id}' ";
			$follow_query_execute = $obj->execute_query($follow_query);

			if($follow_query_execute->num_rows > 0){

              while($fetch_data = mysqli_fetch_assoc($follow_query_execute)){
                extract($fetch_data);
             
            if($blog_id == $blog_following_id && $status == "Followed"){

                ?>
				<a id = 'unfollow' style="float:right" href="followed_process.php?is_followed=Unfollowed&current_blog_id=<?=$blog_id?>&user_id=<?=$_SESSION['user']['user_id']?>" class="btn btn-danger">Unfollow</a>
            <?php 
               }
               elseif($blog_id == $blog_following_id && $status == "Unfollowed"){
                    
            ?>
            <a id = 'follow' style="float:right" href="followed_process.php?is_followed=Followed&current_blog_id=<?=$blog_id?>&user_id=<?=$_SESSION['user']['user_id']?>" class="btn btn-primary">Follow</a>
            <?php 
               }
              }
             }else{
               	?>
               	 <a id = 'follow' style="float:right" href="followed_process.php?is_followed=Followed&current_blog_id=<?=$blog_id?>&user_id=<?=$_SESSION['user']['user_id']?>" class="btn btn-primary">Follow</a>
               <?php
                    
            }
            ?>
				    </h5>
					<p class="card-text"><?=$blog_title?></p>
				<div class="following">
				<a href="detail_page.php?action=view_blog&current_blog_id=<?=$blog_id?>" class="btn btn-primary">see more</a>
				</div>
			</div>
			</div>
	        </div>
         <?php 
          }
          ?>
         
           <nav aria-label="...">
           <ul class="pagination justify-content-center pagination-lg">
          <?php
            $count_blog_query = "SELECT COUNT(blog_id) 'total_blog' FROM blog WHERE blog_status = 'Active'";
            $count_blog_query_execute = $obj->execute_query($count_blog_query);
            if($count_blog_query_execute->num_rows > 0){
                $row = mysqli_fetch_assoc($count_blog_query_execute);
                extract($row);
            }
            $total_blog_record = $total_blog;
         	$per_page_blog = ceil($total_blog_record/$limit);
           for ($loop=1; $loop <= $per_page_blog ; $loop++) { 
           	  ?>
             <li class="page-item mx-1"><a class="page-link" href="index.php?blog_page=<?=$loop?>"><?=$loop?></a></li>             
           	<?php  
            }
            ?>
            </ul>
            </nav>
            <?php

         }
            ?>
		  </div>

	</div>


	<div class="container bg-info-subtle rounded">
	    <div class="row">
	        <div class="col-sm-12" id="about">
	         	<h1 class="fw-bold text-center text-decoration-underline my-5">About Us</h1> 
	        </div> 
	    </div>    	
                <div class="row">
                   	<div class="col-sm-3"></div>
			        <div class="col-sm-6">
			                <img src="https://static.vecteezy.com/system/resources/previews/007/932/867/original/about-us-button-about-us-text-template-for-website-about-us-icon-flat-style-vector.jpg" class="rounded float-start" alt="..." height="400">
			        </div>
                   	<div class="col-sm-3"></div>
                </div>
                
                <div class="row">
                	<div class="col-sm-2"></div>
			        <div class="col-sm-8 my-5">
			         			<p>Lorem ipsum dolor sit amet consectetur adipisicing, elit. Earum officia aliquam in recusandae iure tempore, saepe a dolorum consectetur pariatur dignissimos ullam hic quia, omnis eligendi harum quas dolore nostrum assumenda? Ad qui, ab ipsam nulla, quo error. Dignissimos, minima, blanditiis? Ut laboriosam reprehenderit autem iure architecto tenetur est similique. Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime quod inventore beatae ea quas expedita aspernatur doloribus et dolores. Expedita, esse veritatis cumque reiciendis tenetur reprehenderit a ratione similique cum. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Necessitatibus, repudiandae, vitae? Consectetur eum id suscipit officiis, nam. Placeat, iure optio delectus dignissimos, ad vero repellat aperiam temporibus dolorum amet eos nostrum ab, minus nobis eveniet facere saepe suscipit expedita similique ea debitis! Odit ullam voluptatibus deserunt dignissimos dolorum, est aut, nostrum eos nam perspiciatis porro accusantium hic nihil quam molestias, nobis sapiente repudiandae quibusdam ducimus nisi. Neque, cum dignissimos omnis quis possimus perspiciatis voluptate voluptas in cupiditate assumenda molestiae hic et optio adipisci cumque error amet porro.</p>
			        </div>
                	<div class="col-sm-2"></div>

			    </div>    
	    
	</div>
  
  <div class="container my-5">
  	<div class="row">
  		<div class="col-sm-2"></div>
		    <div class="col-sm-8" id="feedback">
    	  	  <h1 class="text-center bg-dark bg-gradient text-light rounded">Feeedback</h1>
				<div class="card-footer text-body-secondary">	
        <?php
          if(!(isset($_SESSION['user']))){
         ?>
				 <form action="database_file/process.php" onsubmit="return feedback_validation()" method="POST">
						<div class="mb-3">
						  <label  class="form-label">Full Name</label>
						  <input type="text" class="form-control" name="full_name" id="fullname" required>
						  <span id="fullname_msg" class="text-danger"></span>
						</div>
						<div class="mb-3">
						  <label  class="form-label">Email</label>
						  <input type="email" class="form-control" name="email" id="email" required>
						  <span id="email_msg" class="text-danger"></span>

						</div>
						<div class="form-floating">
						  <textarea class="form-control" name="feedback" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px" required></textarea>
						  <label for="floatingTextarea2">Feedback</label>
						</div>
						<button type="submit" name="send_feedback" class="btn btn-primary my-2">Submit</button>
			   </form>
         <?php
           }else{
           	?>
				    <form action="database_file/process.php" method="POST">
                        <label  class="form-label">Full Name</label>
						  <input type="text" class="form-control" name="full_name" id="fullname" value="<?=$_SESSION['user']['first_name']." ".$_SESSION['user']['last_name'] ?>" disabled required>
						  <span id="fullname_msg" class="text-danger"></span>
						</div>
						<div class="mb-3">
						  <label  class="form-label">Email</label>
						  <input type="email" class="form-control" name="email" id="email" value="<?=$_SESSION['user']['email'] ?>"  disabled required>
						  <span id="email_msg" class="text-danger"></span>

						</div>

                        <div class="form-floating">
						  <textarea class="form-control" name="feedback" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px" required></textarea>
						  <label for="floatingTextarea2">Feedback</label>
						</div>
						<button type="submit" name="send_feedback" class="btn btn-primary my-2">Submit</button>
			      </form>

           	<?php
           }
			   ?>
            </div>
        </div>
  		<div class="col-sm-2"></div>
    </div>        
  </div>
<div class="container-fluid my-3" id="team">
    <div class="row">
        <div class="col-12 text-center">
           <h1><span class="bg-success rounded text-light">Our Team</span></h1>
        </div>
    </div>
      
    <div class="row my-3">
       <?php 
        $query = "SELECT * FROM user WHERE role_id = '1'";
        $execute = $obj->execute_query($query);
        if($execute->num_rows > 0){
           while($row = mysqli_fetch_assoc($execute)){
           	extract($row);
       ?>

          <div class="col-sm-4">
                <div class="card" style="width: 18rem;">
                  <img src="<?=$user_image?>" class="card-img-top" alt="...">
                  <div class="card-body">
                    <h5 class="card-title"><?=$first_name." ".$last_name?></h5>
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                  </div>
                </div>
            </div>
           <?php 
             }
            }

           ?>
          
    </div>
</div>		    	
    
<?php
include "require/footer.php";
?>

