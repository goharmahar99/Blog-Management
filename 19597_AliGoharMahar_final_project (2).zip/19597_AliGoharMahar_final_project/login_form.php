<?php
include "require/header.php";
 
?>
<div class="container my-5">
	<div class="row">
	 <div class="col-md-2"></div>
	 <div class="col-md-8">
	 <h1 class="text-center text-light bg-dark bg-gradient rounded">Login Form</h1>
	    <?php  
         if(isset($_REQUEST['show_msg'])){
      ?>
            <p id="show_msg" class="text-center text-light rounded" style="background-color: <?=$_REQUEST['bg_color']?>;"><?=$_REQUEST['show_msg']?></p>
      <?php 
         }
      ?>
	 <form action="database_file/process.php" method="POST">
		
		<div class="mb-3">
		    <label  class="form-label">Email</label>
		    <input type="email" class="form-control" name="email" required>
		</div>
		<div class="mb-3">
		    <label  class="form-label">Password</label>
		    <input type="password" class="form-control" name="password" required>
		</div>
		<input type="submit" name="login" class="bg-primary text-light rounded border border-none fs-5" value="Login">
	 </form>
		<p>If You don't have an account please click here to Registeration....! <a class="btn btn-primary text-decoration-none mx-1" href="registration_form.php" role="button">Register</a></p>
		<p>Forget Password....? <a class="btn btn-primary text-decoration-none mx-1" href="forget_password.php" role="button">Forget Password</a></p>
    </div>
    <div class="col-md-2"></div>
   </div>
</div>
    
<?php
include "require/footer.php";
?>	  