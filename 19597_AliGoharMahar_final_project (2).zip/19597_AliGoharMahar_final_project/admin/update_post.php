<?php
include "require/header.php";
include "sidebar.php";
include "../database_file/database_setting.php";
include "../database_file/database_driver.php";

$obj = new database($hostname,$username,$password,$database);

?>


<div class="col-lg-10 my-3" id="show_response">
 <div class="row">
	<div class="col-md-2"></div>
	<div class="col-md-8">
	  <h1 class="text-center text-light bg-dark bg-gradient rounded">Update Post</h1>
           <?php 

           if(isset($_REQUEST['msg'])){
           ?>
           <p id="show_msg" class="text-center text-light rounded" style="background-color: <?=$_REQUEST['bg_color']?>;"><?=$_REQUEST['msg']?></p>

           <?php
            } 
             if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'update_post'){
                extract($_REQUEST);
                $selected_category = [];
            $selected_categrory_query = "SELECT * FROM category c JOIN post_category pc ON c.category_id = pc.category_id WHERE pc.post_id = '{$post_id}'";
               $result = $obj->execute_query($selected_categrory_query);
                if($result->num_rows > 0){
                     while($row = mysqli_fetch_assoc($result)){
                        extract($row);
                       $selected_category[] = $category_id;
                     }
                }

            $selected_blog_query = "SELECT * FROM post WHERE post_id = '{$post_id}'";
            $result = $obj->execute_query($selected_blog_query);

              if($result->num_rows > 0){
                   $row = mysqli_fetch_assoc($result);
                   extract($row);
                   $selected_blog_id = $blog_id;
              }
              


              $query_1 = "SELECT * FROM post WHERE post_id = '{$post_id}' ";
               $execute_1 = $obj->execute_query($query_1);

               if($execute_1->num_rows > 0){
                   $row_1 = mysqli_fetch_assoc($execute_1);
                   extract($row_1);
                

               }
          }
           ?>
			<form action="post_process.php" method="POST" enctype="multipart/form-data">
			<div class="mb-3">
			  <label  class="form-label">Post Title:</label>
			  <input type="text" class="form-control" name="post_title" value="<?=$post_title?>" required>
			</div>
			<div class="mb-3">
			  <label  class="form-label">Post Summary:</label>
			  <input type="text" class="form-control" name="post_summary" value="<?=$post_summary?>" required>
			</div>
			<div class="form-floating">
			  <textarea class="form-control" name="post_description" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px" required><?=$post_description?></textarea>
			  <label for="floatingTextarea2">Post Description</label>
			</div>
             <?php 
               $query_2 = "SELECT * FROM blog";
               $execute_2 = $obj->execute_query($query_2);
               if($execute_2->num_rows > 0){
               
             ?>
            <select class="form-select my-3" name="blog" aria-label="Default select example" required>
               <option>Choose Blog</option>
               <?php
                
                    while($row_2 = mysqli_fetch_assoc($execute_2)){
                    extract($row_2);

                ?>
            <option value="<?= $blog_id?>" <?= (isset($selected_blog_id) && $selected_blog_id == $blog_id?'selected':'')?>><?=$blog_title?></option>
                <?php
                  }

                 ?> 
           </select>
            <?php
                  
                }

              $query_3 = "SELECT * FROM category";
               $execute_3 = $obj->execute_query($query_3);

               if($execute_3->num_rows > 0){
            ?>
            <select class="form-select my-3" name="category[]" required multiple>
              <option value="">Choose Category</option>

              <?php

                while($row_3 = mysqli_fetch_assoc($execute_3)) {
                    extract($row_3);
                    ?>
            <option  value="<?=$category_id?>" <?php echo (isset($selected_category) && in_array($category_id, $selected_category))?"selected":'' ?>><?=$category_title?></option>

              <?php 
                }
                ?>

           </select>
              <?php
               }else{
              ?>
              <select class="form-select my-2" name="category" aria-label="Default select example">
              <option selected>No category found please add category</option>
              </select>
              <?php 
                }
              ?>

	        <p class="my-2 fw-bold">Post Status:</p>
            <div class="form-check">
                  <input class="form-check-input" type="radio" name="post_status" value="Active"
                    <?php
                      if(isset($post_status)){
                          if($post_status == 'Active'){
                            echo "checked";
                          }
                      }

                    ?>  
                   required>
                  <label class="form-check-label" for="flexRadioDefault1">
                    Active
                  </label>
            </div>

            <div class="form-check">
                  <input class="form-check-input" type="radio" name="post_status" value="InActive" 
                    <?php
                      if(isset($post_status)){
                          if($post_status == 'InActive'){
                            echo "checked";
                          }
                      }

                    ?>

                  required>
                  <label class="form-check-label" for="flexRadioDefault1">
                    InActive
                   </label>
            </div>


            <p class="my-2 fw-bold">Comment Permission:</p>
            <div class="form-check">
                  <input class="form-check-input" type="radio" name="is_comment_allowed" value="1" 
                    <?php
                      if(isset($is_comment_allowed)){
                          if($is_comment_allowed == '1'){
                            echo "checked";
                          }
                      }

                    ?>
                  required>
                  <label class="form-check-label" for="flexRadioDefault1">
                    Comment Allowed
                  </label>
            </div>

            <div class="form-check">
                  <input class="form-check-input" type="radio" name="is_comment_allowed" value="0"
                    <?php
                      if(isset($is_comment_allowed)){
                          if($is_comment_allowed == '0'){
                            echo "checked";
                          }
                      }

                    ?>
                   required>
                  <label class="form-check-label" for="flexRadioDefault1">
                    Comment Not Allowed
                   </label>
            </div>
             
             <input type="hidden" name="current_post_id" value="<?=$post_id?>">
             <input type="hidden" name="previous_image" value="<?=$featured_image?>">
             <input type="hidden" name="no_of_attachment" value="<?=$no_of_attachment?>">

			<div class="mb-3 my-2">
			  <label for="formFile" class="form-label">Featured Image: &nbsp;&nbsp;&nbsp;
          <?php
          if(isset($featured_image)){
            ?>
          <span class="mx-5">previous image <img src="../<?=$featured_image??''?>" alt="" style="height: 50px; width: 50px;"> </span>
            <?php 
             }
            ?>
        </label>

			  <input class="form-control" name="featured_img" type="file">
			</div>


            <div class="mb-3">
			  <label  class="form-label">No: of Attachment:</label>
			  <input type="number" class="form-control" value="<?=$counter?>" name="no_of_attachment">
			</div>             


            <div>
            <button type="submit" name="update_post" class="btn btn-primary my-2">Update Post</button>
			</form>
		    </div>
  </div>
  <div class="col-md-2"></div>
 </div>

  <?php
        
         $query = "SELECT * FROM post p JOIN blog b  ON b.blog_id = p.blog_id  WHERE  b.user_id = '{$_SESSION['user']['user_id']}' ORDER BY p.post_id DESC";

           $execute = $obj->execute_query($query);	

            if($execute->num_rows > 0){
                           	   
     ?>

 <div class="row">
 	<div class="col-md-12">
 		<table id="tables" class="display" style="width:100%">
          <thead>
            <tr>
                <th>Post Id</th>
                <th>Blog Title</th>
                <th>Post Title</th>
                <th>Post Summary</th>
                <th>Post Description</th>
                <th>Post Category</th>
                <th>Featured Image</th>
                <th>Post Attachment</th>
                <th>Post Status</th>
                <th>Is_Comment_Allowed</th>
                <th>Action</th>
            </tr>
          </thead>
          <tbody>
           <?php

             while($row = mysqli_fetch_assoc($execute)){
             	extract($row);
           ?>
            <tr>
                <td><?= $post_id?></td>
                <td><?= $blog_title?></td>
                <td><?= substr($post_title,0,100)?></td>
                <td><?= substr($post_summary,0,100)?></td>
                <td><?= substr($post_description,0,100)?></td>
                <td><?php $query_1 = "SELECT * FROM category c JOIN post_category pc ON c.category_id = pc.category_id  WHERE pc.post_id = '{$post_id}'";
                          $result = $obj->execute_query($query_1);
                          if($result->num_rows > 0){
                          while($fetch_data = mysqli_fetch_assoc($result)) {
                               extract($fetch_data);
                            echo $category_title."<br>";  
                          }
                        }
                  ?></td>
                <td><img src="../<?=$featured_image?>" style="height: 50px; width: 50px;"></td>
                <td><?php
                     $query_2 = "SELECT  * FROM post_atachment WHERE post_id = '{$post_id}'";

                     $execute_2 = $obj->execute_query($query_2);
                       $counter = 0;
                     if($execute_2){
                        while($row_2 = mysqli_fetch_assoc($execute_2)) {
                            extract($row_2);
                           $counter++;
                        echo   $post_attachment_title."<br>";
                        ?>
                          <img src="../<?=$post_attachment_path?>" style="height: 30px; width:30px;"> 
                        <?php  
                      }
                     }

                 ?></td>
                <td><?= $post_status?></td>
                <td><?= $is_comment_allowed?></td>
                <td><a href="update_post.php?action=update_post&post_id=<?=$post_id?>&counter=<?=$counter?>" type="submit"   class="btn btn-success">Update</a>
                </td>
            </tr>
            <?php
             }
            
            }

            ?>
            
          </tbody>
        </table>

 	</div>
 </div>
</div>






<?php
include "require/footer.php";
?>