<?php 

include "../database_file/database_setting.php";
include "../database_file/database_driver.php";
$obj = new database($hostname,$username,$password,$database);
if(isset($_REQUEST['add_post'])){
  // echo "<pre>";
  // print_r($_REQUEST);
  // echo "</pre>";

  // die();
	  extract($_REQUEST);
    $dir = "../images";
    if(!(is_dir($dir))){
       if(!(mkdir($dir))){
         echo "$dir folder is not created";
       }
    }

    $file_name = rand()."_".$_FILES['featured_img']['name'];
    $file_temp_name =  $_FILES['featured_img']['tmp_name'];

    $file_path = "images/post_image/".$file_name;

    if(move_uploaded_file($file_temp_name, "../".$file_path)){
      $post_title = htmlspecialchars($post_title);
      $post_description = htmlspecialchars($post_description);

      $query = "INSERT INTO post values('null','{$blog}','{$post_title}','{$post_summary}','{$post_description}','{$file_path}','{$post_status}','{$is_comment_allowed}',Now(),'null')";
    
      $execute = $obj->execute_query($query); 
      if($execute){
      $post_id = mysqli_insert_id($obj->connection);


       }

     if(isset($category)){
       if(is_array($category)){
          foreach ($category as $key => $value) {
            $query = "INSERT INTO post_category values('null','{$post_id}','{$value}',Now(),'Null')";
   //         echo $query;
            $execute = $obj->execute_query($query);
 // echo "Ok";
 // die();
          }
       }
     }
    }

    if(isset($_REQUEST['no_of_attachment']) && $_REQUEST['no_of_attachment'] != ""){
        include "require/header.php";
        include "sidebar.php";
      $no_of_attachment = $_REQUEST['no_of_attachment'];
      	
        ?>
    <div class="col-lg-10 my-3"> 
     <div class="row">
       <div class="col-md-2"></div> 
       <div class="col-md-8">  
        <center>
          <form action="process.php" method="POST" enctype="multipart/form-data">
         <?php
        for($loop=1; $loop <= $no_of_attachment; $loop++){ 
      	?>  
      	   <h2 class="text-center text-light bg-dark bg-gradient">Attachment <?=$loop?></h2>
            <div class="mb-3">
              <label  class="form-label">Attachment Title</label>
              <input type="text" class="form-control" name="attachment_title_<?=$loop?>">
            </div> 

            <div class="mb-3">
              <label  class="form-label">Attachment File</label>
              <input type="file" class="form-control" name="attachment_file_<?=$loop?>">
            </div> 
        <?php 
            }
        ?>
            <input type="hidden" name="post_id" value="<?= $post_id?>">
            <input type="hidden" name="no_of_attachment" value="<?= $no_of_attachment?>">

              <button type="submit" class="btn btn-primary my-2" name="add_attachment">Submit</button>
          </form>
        </center>
       </div>
       <div class="col-md-2"></div> 
     </div>
    </div>
      	   <?php
       include "require/footer.php";
    }else{
      header("location: add_post.php?msg=Post Added Successfully&bg_color=green");
    }

}elseif(isset($_REQUEST['update_post'])){
   extract($_REQUEST);
  //  print_r($_FILES);
   // echo "<pre>";
   // print_r($_REQUEST);
   // echo "</pre>";
   // die;
   // echo $previous_image;
   // die;
        $dir = "../images";
    if(!(is_dir($dir))){
       if(!(mkdir($dir))){
         echo "$dir folder is not created";
       }
    }
    if(isset($_FILES['featured_img']['name'])&&$_FILES['featured_img']['name']!=""){
        // echo "dsdas";
        // die;
      $file_name = rand()."_".$_FILES['featured_img']['name'];
      $file_temp_name =  $_FILES['featured_img']['tmp_name'];
      $file_path = "images/post_image/". $file_name;
      $post_img = $file_path;
      if(move_uploaded_file($file_temp_name, '../'.$post_img)){

        // echo "dksd";
        // die;
        $query = "UPDATE post SET post_title = '{$post_title}', post_summary =  '{$post_summary}',post_description = '{$post_description}',featured_image = '{$post_img}', post_status = '{$post_status}', is_comment_allowed = '{$is_comment_allowed}',updated_at = Now() WHERE post_id = '{$current_post_id}'";
        // echo $query;
        // die;
      $execute = $obj->execute_query($query); 
      }
     
    }
    else{
      // echo "ssdasd";
      // die;
        $post_img = $previous_image;

      $query = "UPDATE post SET post_title = '{$post_title}', post_summary =  '{$post_summary}',post_description = '{$post_description}',featured_image = '{$post_img}', post_status = '{$post_status}', is_comment_allowed = '{$is_comment_allowed}',updated_at = Now() WHERE post_id = '{$current_post_id}'";
      // echo $query;
      // die;
      $execute = $obj->execute_query($query); 
    }
    // die;
     if(isset($_REQUEST['category'])){
       if(is_array($_REQUEST['category'])){
        $query_1 = "DELETE FROM post_category WHERE post_id = '{$current_post_id}'";
          $execute_1 = $obj->execute_query($query_1);
          foreach ($category as $key => $value) {
            $query_2 = "INSERT INTO post_category values('null','{$current_post_id}','{$value}',Null,Now())";
            // echo $query_2;
            // die;   
            $execute_2 = $obj->execute_query($query_2);
          }
       }
     }
    if(isset($_REQUEST['no_of_attachment']) && $_REQUEST['no_of_attachment'] !=0){
        include "require/header.php";
        include "sidebar.php";
      $no_of_attachment = $_REQUEST['no_of_attachment'];
      // echo $no_of_attachment;
      // die;
         $query = "SELECT * FROM post_atachment WHERE post_id = '{$current_post_id}'";
           $execute = $obj->execute_query($query);
          
           if($execute->num_rows >= 0){ 

        ?>
    <div class="col-lg-10 my-3"> 
     <div class="row">
       <div class="col-md-2"></div> 
       <div class="col-md-8">  
        <h1 class="bg-dark bg-gradient text-center text-light rounded ">Update Attachment</h1>
        <center>
          <form action="process.php" method="POST" enctype="multipart/form-data">
         <?php
        for($loop=1; $loop <= $no_of_attachment; $loop++){ 
            $row = mysqli_fetch_assoc($execute);
            extract($row);
        ?>  
           <h2 class="text-center text-light bg-secondary bg-gradient rounded my-5">Attachment <?=$loop?></h2>
            <div class="mb-3">
              <label  class="form-label">Attachment Title</label>
              <input type="text" class="form-control" name="attachment_title_<?=$loop?>" value="<?=$post_attachment_title?>">
            </div> 
               <input type="hidden" name="previous_img_<?=$loop?>" value="<?=$post_attachment_path?>">
               <input type="hidden" name="post_id" value="<?=$current_post_id?>">
            <div class="mb-3">
              <label  class="form-label">Attachment File: <span class="ms-5">previous file: <img src="../<?=$post_attachment_path?>" style="height: 50px;width: 50px;"></span></label>
              <input type="file" class="form-control" name="attachment_file_<?=$loop?>">
            </div> 
        <?php 
            }
        ?>
            <input type="hidden" name="post_id" value="<?= $post_id?>">
            <input type="hidden" name="no_of_attachment" value="<?= $no_of_attachment?>">

              <button type="submit" class="btn btn-primary my-2" name="update_attachment">Submit</button>
          </form>
        </center>
       </div>
       <div class="col-md-2"></div> 
     </div>
    </div>
           <?php
       include "require/footer.php";
      }
    }else{
            header("location: update_post.php?msg=Post Updated Successfully&bg_color=green");

    }
}

?>