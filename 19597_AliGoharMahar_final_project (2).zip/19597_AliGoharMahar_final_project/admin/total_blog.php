<?php
include "require/header.php";
include "sidebar.php";
include "../database_file/database_setting.php";
include "../database_file/database_driver.php";

$obj = new database($hostname,$username,$password,$database);
?>
   
<div class="col-lg-10 my-3 table-resposive" id="show_response">
 <div class="row">
	<div class="col-md-12">
    <h1 class="text-center text-light bg-dark bg-gradient rounded">Total Blog</h1>
          <?php
           $query = "SELECT b.*, CONCAT(u.first_name,' ',u.last_name) 'full_name' FROM blog b JOIN user u ON u.user_id = b.user_id";
            $execute = $obj->execute_query($query);

            if($execute->num_rows > 0){
          ?>
	    <table id="tables" class="display" style="width:100%">
          <thead>
            <tr>
                <th>Blog Id</th>
                <th>User Name</th>
                <th>Blog Title</th>
                <th>Post Per Page</th>
                <th>Blog Background Image</th>
                <th>Blog Status</th>
                <th>Created at</th>
                <th>Updated at</th>
                <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php 
             while($row = mysqli_fetch_assoc($execute)) {
                extract($row); 
             ?>
            <tr>
                <td><?= $blog_id?></td>
                <td><?= $full_name?></td>
                <td><?= $blog_title?></td>
                <td><?= $post_per_page?></td>
                <td><img src="../<?= $blog_background_image?>" height="50" style="height: 60px;width: 80px;"></td>
                <td><?= $blog_status?></td>
                <td><?= $created_at?></td>
                <td><?= $updated_at?></td>
                <td>
                    <?php 
                      if($blog_status == 'Active'){
                          ?>
                        <a class="btn btn-danger" href="process.php?action=Blog_InActive&blog_id=<?=$blog_id?>">InAcive</a>
                        <?php 
                         }else{
                          ?>
                            <a class="btn btn-success" href="process.php?action=Blog_Active&blog_id=<?=$blog_id?>">Active</a>
                          <?php
                         }
                         ?>
                       </td>

            </tr>
            
             <?php } ?>
          </tbody>
        </table>
    <?php } ?>
	</div>
 </div>
</div>








<?php
include "require/footer.php";
?>