<?php
include "require/header.php";
include "sidebar.php";
?>
<div class="col-lg-10 my-3" id="show_response">
 <div class="row">
	<div class="col-md-2"></div>
	<div class="col-md-8">
		<h1 class="text-center text-light bg-dark bg-gradient rounded">Add Blog</h1>
		<?php
         if(isset($_REQUEST['msg'])){
           ?>
           <p id="show_msg" class="text-center text-light rounded" style="background-color: <?=$_REQUEST['bg_color']?>;"><?=$_REQUEST['msg']?></p>
           
         <?php
         }

		?>
  
			<form action="process.php" method="POST" enctype="multipart/form-data">
			<div class="mb-3">
			  <label  class="form-label">Blog Title</label>
			  <input type="text" class="form-control" name="blog_title" required>
			</div>
			<div class="mb-3">
			  <label  class="form-label">Post Per Page</label>
			  <input type="number" class="form-control" name="post_per_page" required min="1">
			</div>
			<div class="mb-3">
			  <label for="formFile" class="form-label">Blog Background Image</label>
			  <input class="form-control" type="file" name="blog_bg_img" id="formFile" required>

      	<p class="my-3 fw-bold">Blog Status</p>
        <div class="form-check">
				  <input class="form-check-input" type="radio" name="gender" value="Active">
				  <label class="form-check-label" for="flexRadioDefault1">
				    Active
				  </label>
				</div>
				<div class="form-check">
				  <input class="form-check-input" type="radio" name="gender" value="InActive">
				  <label class="form-check-label" for="flexRadioDefault1">
				    InActive
				   </label>
				</div>

			</div> 
			<button type="submit" name="add_blog" class="btn btn-primary">Submit</button>
			</form>
	</div>
	<div class="col-md-2"></div>
 </div>
</div>



<?php
include "require/footer.php";
?>