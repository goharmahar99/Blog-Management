<?php
include "require/header.php";
include "sidebar.php";
include "../database_file/database_setting.php";
include "../database_file/database_driver.php";

$obj = new database($hostname,$username,$password,$database);
?>
<div class="col-lg-10 my-3" id="show_response">
  <div class="row">
	<div class="col-md-2"></div>
	<div class="col-md-8">
		<h1 class="text-center text-light bg-dark bg-gradient rounded">Update Blog</h1>
        <?php
          if(isset($_REQUEST['msg'])){
          ?>
           <p id="show_msg" class="bg-secondary rounded text-center text-light" style="background-color: <?= $_REQUEST['bg_color']?>;"><?= $_REQUEST['msg']?></p>
          <?php
          }

    if(isset($_REQUEST['action']) && $_REQUEST['action']== 'update_blog'){
      extract($_REQUEST);
    //print_r($_REQUEST);

      $query = "SELECT * FROM blog WHERE blog_id = '{$blog_id}'";
      $execute = $obj->execute_query($query);

      if($execute->num_rows > 0){
         $row = mysqli_fetch_assoc($execute);
          extract($row);
       }

     }
        ?>
			<form action="process.php" method="POST" enctype="multipart/form-data">
			<div class="mb-3">
			  <label  class="form-label">Blog Title</label>
			  <input type="text" class="form-control" name="blog_title" value="<?=$blog_title??''?>">
			</div>
			<div class="mb-3">
			  <label  class="form-label">Post Per Page</label>
			  <input type="number" class="form-control" name="post_per_page" value="<?=$post_per_page??''?>">
			</div>


            <p class="my-2 fw-bold">Blog Status</p>
            <div class="form-check">
                  <input class="form-check-input" type="radio" name="gender" value="Active" 
                  <?php 
                   if(isset($blog_status)){
                       if($blog_status == 'Active'){
                          echo "checked";
                       }  
                   }
                  ?>
                  >
                  <label class="form-check-label" for="flexRadioDefault1">
                    Active
                  </label>
            </div>
            <div class="form-check">
                  <input class="form-check-input" type="radio" name="gender" value="InActive"
                  <?php 
                   if(isset($blog_status)){
                       if($blog_status == 'InActive'){
                          echo "checked";
                       }  
                   }
                  ?>
                  >
                  <label class="form-check-label" for="flexRadioDefault1">
                    InActive
                   </label>
            </div>



            <input type="hidden" type="number" name="blog_id" value="<?=$blog_id??''?>">
			<input type="hidden" type="file" name="blog_bg_img" value="<?=$blog_background_image??''?>">
			<div class="mb-3 my-2">
			  <label for="formFile" class="form-label">Background Image &nbsp;&nbsp;&nbsp;&nbsp; <?php  
                   if(isset($blog_background_image)){
                    ?>
                   <span>previous background image: <img src="../<?=$blog_background_image??''?>" height="50"></span>
                <?php
                   }
               ?></label>
			  <input class="form-control" type="file" name="blog_image_background" id="formFile">
			</div> 
			<button type="submit" name="blog_save_change" class="btn btn-primary">Submit</button>
			</form>
	</div>
	<div class="col-md-2"></div>
  </div>
     <?php
        
         $query = "SELECT b.*, CONCAT(u.first_name,' ',u.last_name) 'full_name' FROM blog b JOIN user u WHERE u.user_id = '{$_SESSION['user']['user_id']}' ORDER BY b.blog_id DESC";
         $execute = $obj->execute_query($query);	

         if($execute->num_rows > 0){
     ?>
   <div class="col-lg-2"></div>
   <div class="col-lg-10 my-2">    
   <div class="row">
   	<div class="col-md-12">
     <table id="tables" class="display" style="width:100%">
          <thead>
            <tr>
                <th>Blog Id</th>
                <th>User Name</th>
                <th>Blog Title</th>
                <th>Post Per Page</th>
                <th>Blog Background Image</th>
                <th>Blog status</th>
                <th>Created at</th>
                <th>Update at</th>
                <th>Action</th>
            </tr>
          </thead>
          <tbody>
           <?php
             while($row = mysqli_fetch_assoc($execute)){
             	extract($row);
           ?>
            <tr>
                <td><?= $blog_id?></td>
                <td><?= $full_name?></td>
                <td><?= $blog_title?></td>
                <td><?= $post_per_page?></td>
                <td><img src="../<?= $blog_background_image?>" alt="" height="50" style="height: 60px;width: 80px;"></td>
                <td><?= $blog_status?></td>
                <td><?= $created_at?></td>
                <td><?= $updated_at?></td>
                <td><a href="update_blog.php?action=update_blog&blog_id=<?=$blog_id?>" type="submit"   class="btn btn-success">Update</a>
                </td>
            </tr>
            <?php
             }
            } 
            

            ?>
            
          </tbody>
        </table>
    </div>    

  </div>      
   </div>

</div>

<?php
include "require/footer.php";
?>