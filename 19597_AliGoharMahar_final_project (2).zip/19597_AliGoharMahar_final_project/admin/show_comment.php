<?php
include "require/header.php";
include "sidebar.php";
include "../database_file/database_setting.php";
include "../database_file/database_driver.php";

$obj = new database($hostname,$username,$password,$database);
?>
   
<div class="col-lg-10" id="show_response">
 <div class="row">
	<div class="col-md-12">
    <h1 class="text-center text-light bg-dark bg-gradient rounded my-5">Total Comment</h1>
          <?php
           $query = "SELECT * FROM post_comment";
            $execute = $obj->execute_query($query);

            if($execute->num_rows > 0){
          ?>
	    <table id="tables" class="display" style="width:100%">
          <thead>
            <tr>
                <th>Post_Comment_Id</th>
                <th>Post_Id</th>
                <th>User_Id</th>
                <th>Comment</th>
                <th>Is_Active</th>
                <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php 
             while($row = mysqli_fetch_assoc($execute)) {
                extract($row); 
             ?>
            <tr>
                <td><?= $post_comment_id?></td>
                <td><?= $post_id?></td>
                <td><?= $user_id?></td>
                <td><?= $comment?></td>
                <td><?= $is_active?></td>
                <td>
                  <?php 
                    if(isset($is_active) && $is_active == 'Active'){
                  ?>
                  <a href="../database_file/process.php?action=in_active_comment&comment_id=<?=$post_comment_id?>" class="btn btn-danger">In_Active</a>
                    <?php 
                    }else{
                    ?>
                      <a href="../database_file/process.php?action=active_comment&comment_id=<?=$post_comment_id?>" class="btn btn-success">Active</a>
                    <?php 
                    }
                    ?>  
                </td>
            </tr>
            
             <?php } ?>
          </tbody>
        </table>
    <?php } ?>
	</div>
 </div>
</div>








<?php
include "require/footer.php";
?>