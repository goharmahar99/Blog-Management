<?php
include "require/header.php";
include "sidebar.php";
include "../database_file/database_setting.php";
include "../database_file/database_driver.php";

$obj = new database($hostname,$username,$password,$database);
?>

<div class="col-lg-10 my-3" id="show_response">
 <div class="row">
	<div class="col-md-2"></div>
	<div class="col-md-8">
	  <h1 class="text-center text-light bg-dark bg-gradient rounded">Update Category</h1>

	     <?php  
        if(isset($_REQUEST['msg'])){
        ?>
         <p id="show_msg" class="text-light text-center rounded" style="background-color:<?=$_REQUEST['bg_color']?>;"><?= $_REQUEST['msg']?></p>
        <?php
        }

    if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'update_category_btn'){
       extract($_REQUEST);

     $query = "SELECT * FROM category WHERE category_id = $category_id";
   
     $execute = $obj->execute_query($query);

     if($execute->num_rows > 0){
         $row = mysqli_fetch_assoc($execute);
         extract($row);
     }else{
      header("location: update_category.php");
     }
   }

	     ?>
 
			<form action="process.php" method="POST">
			<div class="mb-3">
			  <label  class="form-label">Category Title</label>
			  <input type="text" class="form-control" name="category_title" value="<?=$category_title??''?>" required>
			</div>

			<div class="form-floating">
			  <textarea class="form-control" name="category_description" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px"  required><?=$category_description??''?></textarea>
			  <label for="floatingTextarea2">Category Description</label>
			</div>


	        <p class="my-2 fw-bold">Category Status</p>
            <div class="form-check">
                  <input class="form-check-input" type="radio" name="category_status" value="Active" required
                  <?php 
                   if(isset($category_status)){
                       if($category_status == 'Active'){
                          echo "checked";
                       }  
                   }
                  ?>
                   >
                  <label class="form-check-label" for="flexRadioDefault1">
                    Active
                  </label>
            </div>

            <div class="form-check">
                  <input class="form-check-input" type="radio" name="category_status" value="InActive" required
                  <?php 
                   if(isset($category_status)){
                       if($category_status == 'InActive'){
                          echo "checked";
                       }  
                   }
                  ?>
                  >
                  <label class="form-check-label" for="flexRadioDefault1">
                    InActive
                   </label>
            </div>
             
             <input type="hidden" name="category_id" value="<?=$category_id??''?>">

            <button type="submit" name="category_save_change" class="btn btn-primary my-2">Save Change</button>
			</form>
  </div>
  <div class="col-md-2"></div>
 </div>

<?php

$query = "SELECT * FROM category";
$execute = $obj->execute_query($query);

if($execute->num_rows > 0){
	?>
  <div class="row">
   	<div class="col-md-12">
     <table id="tables" class="display" style="width:100%">
          <thead>
            <tr>
                <th>Category Id</th>
                <th>Category Title</th>
                <th>Category Description</th>
                <th>Category Status</th>
                <th>Created_at</th>
                <th>Updated_at</th>
                <th>Action</th>
            </tr>
          </thead>
          <tbody>
           <?php
             while($row = mysqli_fetch_assoc($execute)){
             	extract($row);
           ?>
            <tr>
                <td><?= $category_id?></td>
                <td><?= $category_title?></td>
                <td><?= $category_description?></td>
                <td><?= $category_status?></td>
                <td><?= $created_at?></td>
                <td><?= $updated_at?></td>
                <td><a href="update_category.php?action=update_category_btn&category_id=<?=$category_id?>" type="submit"   class="btn btn-success">Update</a>
                </td>
            </tr>
            <?php
             }
            } 
            ?>
            
          </tbody>
        </table>
    </div>    
   </div>
</div>












<?php
include "require/footer.php";
?>