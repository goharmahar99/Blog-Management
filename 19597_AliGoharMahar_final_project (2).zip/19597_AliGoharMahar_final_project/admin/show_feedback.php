<?php
include "require/header.php";
include "sidebar.php";
include "../database_file/database_setting.php";
include "../database_file/database_driver.php";

$obj = new database($hostname,$username,$password,$database);
?>
   
<div class="col-lg-10" id="show_response">
 <div class="row">
	<div class="col-md-12">
    <h1 class="text-center text-light bg-dark bg-gradient rounded my-5">Total Feedback</h1>
          <?php
           $query = "SELECT * FROM user_feedback";
            $execute = $obj->execute_query($query);

  if($execute->num_rows > 0){
          ?>
	    <table id="tables" class="display" style="width:100%">
          <thead>
            <tr>
                <th>Feedback Id</th>
                <th>User Id</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Feedback</th>
                <th>Created at</th>
            </tr>
          </thead>
          <tbody>
            <?php 
             while($row = mysqli_fetch_assoc($execute)) {
                extract($row); 
             ?>
            <tr>
                <td><?= $feedback_id?></td>
                <td><?= $user_id?></td>
                <td><?= $user_name?></td>
                <td><?= $user_email?></td>
                <td><?= $feedback?></td>
                <td><?= $created_at?></td>
            </tr>
            
             <?php } ?>
          </tbody>
        </table>
    <?php }else{
      ?>
    <h1 class="text-center text-light bg-secondary bg-gradient rounded my-5">No Record Found</h1>
        
    <?php
    } 
    ?>
	</div>
 </div>
</div>








<?php
include "require/footer.php";
?>