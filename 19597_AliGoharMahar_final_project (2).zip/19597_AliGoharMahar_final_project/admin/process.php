<?php
session_start();
include "../database_file/database_setting.php";
include "../database_file/database_driver.php";
$obj = new database($hostname,$username,$password,$database);

if(isset($_REQUEST['add_blog'])){
   extract($_REQUEST);
 if($post_per_page > 0){
  $dir = "../images";

  if(!(is_dir($dir))){
      if(!(mkdir($dir))){
         echo "$dir directory is not created";
      }
  }  

  $file_name = rand()."_".$_FILES['blog_bg_img']['name'];
  $file_tmp_name = $_FILES['blog_bg_img']['tmp_name'];

  $file_path = "images/blog_image/".$file_name;

  if(move_uploaded_file($file_tmp_name, "../".$file_path)){
    $blog_title = htmlspecialchars($blog_title);
    $query = "INSERT INTO blog values('null','{$_SESSION['user']['user_id']}','{$blog_title}','{$post_per_page}','{$file_path}','{$gender}',Now(),'Null')";
    $execute = $obj->execute_query($query);

    if($execute){
      header("location: add_blog.php?msg=Blog Added Successfully&bg_color=green&show_msg=show_msg");
    }
    }else{
      header("location: add_blog.php?msg=post per page must be greater than 0&bg_color=red&show_msg=show_msg");
    }
  }

} elseif(isset($_REQUEST['blog_save_change'])){
	extract($_REQUEST);

    $dir = "../images";
    if(!(is_dir($dir))){
      if(!(mkdir($dir))){
         echo "$dir folder is not created";
      }	
    }

    $file_name = rand()."_".$_FILES['blog_image_background']['name'];
    $file_tmp_name = $_FILES['blog_image_background']['tmp_name'];
    $file_path = "images/blog_image/".$file_name;

     if($_FILES['blog_image_background']['name'] == ''){
        $img_path = $blog_bg_img;
     }else{
     	$img_path = $file_path;
     }


    move_uploaded_file($file_tmp_name, "../$img_path");    

    $query = "UPDATE blog SET blog_title = '{$blog_title}', post_per_page = '{$post_per_page}', blog_background_image = '{$img_path}', blog_status = '{$gender}', updated_at = Now() WHERE blog_id = '{$blog_id}'";
     $execute = $obj->execute_query($query);

     if($execute){
        header("location: update_blog.php?msg=Blog Updated Successfully...!&bg_color=green&show_msg=show_msg");
     
   }else{
     	echo "Blog Not Updated..";

     }

}elseif(isset($_REQUEST['add_category'])){
     //print_r($_REQUEST);
     extract($_REQUEST);

     $query = "INSERT INTO category values('null','{$category_title}','{$category_description}','{$category_status}',Now(),'null')";
   
     $execute = $obj->execute_query($query);

     if($execute){
       header("location: add_category.php?msg=Category Added Successfully...!&bg_color=green&show_msg=show_msg");
     }else{
       header("location: add_category.php?msg=Category Not Added...!&bg_color=red&show_msg=show_msg");
     }
}elseif(isset($_REQUEST['category_save_change'])){
       extract($_REQUEST);
     $query = "UPDATE category SET category_title = '{$category_title}',category_description = '{$category_description}',category_status = '{$category_status}',updated_at = Now() WHERE category_id = $category_id";
     $execute = $obj->execute_query($query);

     if($execute){
      header("location: update_category.php?msg=Category Updated Successfully...!&bg_color=green&show_msg=show_msg");
     }else{
      header("location: update_category.php?msg=Category Not Updated...!&bg_color=red&show_msg=show_msg");

     } 

}elseif(isset($_REQUEST['add_attachment'])){
    extract($_REQUEST);

  for($loop=1; $loop <=$no_of_attachment ; $loop++){ 
    $dir = "../images";
    if(!(is_dir($dir))){
       if(!(mkdir($dir))){
         echo "$dir folder is not created";
       }
    }
    $attachment_title = $_REQUEST['attachment_title_'.$loop];
    $file_name =  rand()."_".$_FILES['attachment_file_'.$loop]['name'];
    $file_temp_name =  $_FILES['attachment_file_'.$loop]['tmp_name'];


    $post_attachment_path = "images/attachment/". $file_name;

    if(move_uploaded_file($file_temp_name, "../$post_attachment_path")){
    
      
    $query = "INSERT INTO post_atachment values('null','{$post_id}','{$attachment_title}','{$post_attachment_path}','Active',Now(),'null')";
    
   $execute = $obj->execute_query($query);
   if($execute){
      header("location: add_post.php?msg=Post and Attachment Added Successfully&bg_color=green&show_msg=show_msg");
     
   } 
 }
  }
   

  }elseif(isset($_REQUEST['update_attachment'])){
    extract($_REQUEST);
  for($loop=1; $loop <=$no_of_attachment ; $loop++){ 
    $dir = "../images";
    if(!(is_dir($dir))){
       if(!(mkdir($dir))){
         echo "$dir folder is not created";
       }
    }
     $attachment_title = $_REQUEST['attachment_title_'.$loop];
     $previous_img =     $_REQUEST['previous_img_'.$loop];
     $file_name =  rand()."_".$_FILES['attachment_file_'.$loop]['name'];
     $file_temp_name =  $_FILES['attachment_file_'.$loop]['tmp_name'];

     $post_attachment_path = "images/attachment/".$file_name;

    echo "working";
     move_uploaded_file($file_temp_name, "../$post_attachment_path");
    
      if($_FILES["attachment_file_$loop"]['name'] == ''){
          $attachment_file = $previous_img;
      }else{
        $attachmnet_file = $post_attachment_path;
      }
           
      
   $query = "UPDATE post_atachment SET post_attachment_title = '{$attachment_title}',post_attachment_path ='{$post_attachment_path}',is_active = 'Active', updated_at = Now() WHERE post_id = '{$post_id}'";
    
   $execute = $obj->execute_query($query);
   if($execute){
      header("location: update_post.php?msg=Post and Attachment Updated Successfully&bg_color=green&show_msg=show_msg");
    } 
  } 
  
   

  }elseif(isset($_REQUEST['action']) && $_REQUEST['action'] == 'Post_InActive'){
        extract($_REQUEST);
        
        $query = "UPDATE post SET post_status = 'InActive' WHERE post_id = '{$post_id}' ";
        $execute = $obj->execute_query($query);

        if($execute){
           header("location: total_post.php");
        }
  }elseif(isset($_REQUEST['action']) && $_REQUEST['action'] == 'Post_Active'){
        extract($_REQUEST);
        
        $query = "UPDATE post SET post_status = 'Active' WHERE post_id = '{$post_id}' ";
        $execute = $obj->execute_query($query);

        if($execute){
           header("location: total_post.php");
        }
  }elseif(isset($_REQUEST['action']) && $_REQUEST['action'] == 'Blog_InActive'){
        extract($_REQUEST);
        
        $query = "UPDATE blog SET blog_status = 'InActive' WHERE blog_id = '{$blog_id}' ";
        $execute = $obj->execute_query($query);

        if($execute){
           header("location: total_blog.php");
        }
  }elseif(isset($_REQUEST['action']) && $_REQUEST['action'] == 'Blog_Active'){
        extract($_REQUEST);
        
        $query = "UPDATE blog SET blog_status = 'Active' WHERE blog_id = '{$blog_id}' ";
        $execute = $obj->execute_query($query);

        if($execute){
           header("location: total_blog.php");
        }
  }elseif(isset($_REQUEST['action']) && $_REQUEST['action'] == 'Comment_InActive'){
        extract($_REQUEST);
        $query = "UPDATE post_comment SET is_active = 'InActive' WHERE post_comment_id = '{$comment_id}'";
        $execute = $obj->execute_query($query);

        if($execute){
           header("location: view_post_comment.php?post_id=$post_id");
        }
  }elseif(isset($_REQUEST['action']) && $_REQUEST['action'] == 'Comment_Active'){
        extract($_REQUEST);
        
        $query = "UPDATE post_comment SET is_active = 'Active' WHERE post_comment_id = '{$comment_id}'";
        $execute = $obj->execute_query($query);

        if($execute){
           header("location: view_post_comment.php?post_id=$post_id");
        }
  }






?>