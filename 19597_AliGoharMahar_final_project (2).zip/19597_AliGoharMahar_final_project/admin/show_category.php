<?php
include "require/header.php";
include "sidebar.php";
include "../database_file/database_setting.php";
include "../database_file/database_driver.php";

$obj = new database($hostname,$username,$password,$database);
?>
   
<div class="col-lg-10 table-responsive" id="show_response">
 <div class="row">
	<div class="col-md-12">
    <h1 class="text-center text-light bg-dark bg-gradient rounded">Total Categories</h1>
          <?php
           $query = "SELECT * FROM category";
            $execute = $obj->execute_query($query);

            if($execute->num_rows > 0){
          ?>
	    <table id="tables" class="display" style="width:100%">
          <thead>
            <tr>
                <th>Category Id</th>
                <th>Category Title</th>
                <th>Category Description</th>
                <th>Category Status</th>
                <th>Created at</th>
                <th>Updated at</th>
            </tr>
          </thead>
          <tbody>
            <?php 
             while($row = mysqli_fetch_assoc($execute)) {
                extract($row); 
             ?>
            <tr>
                <td><?= $category_id?></td>
                <td><?= $category_title?></td>
                <td><?= $category_description?></td>
                <td><?= $category_status?></td>
                <td><?= $created_at?></td>
                <td><?= $updated_at?></td>
            </tr>
            
             <?php } ?>
          </tbody>
        </table>
    <?php } ?>
	</div>
 </div>
</div>








<?php
include "require/footer.php";
?>