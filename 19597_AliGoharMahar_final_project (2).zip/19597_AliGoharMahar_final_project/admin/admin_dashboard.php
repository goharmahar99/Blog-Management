
<?php
include "require/header.php";
include "../database_file/database_setting.php";
include "../database_file/database_driver.php";

$obj = new database($hostname,$username,$password,$database);

?>



<div class="container-fluid m-0 p-0">
  <div class="row">
    <div class="col-lg-2">
      <div class="flex-shrink-0 bg-secondary">
          <ul class="list-unstyled ps-0">
            <li class="mb-1">
              <button class="btn btn-toggle d-inline-flex align-items-center rounded border-0 collapsed" data-bs-toggle="collapse" data-bs-target="#blog-collapse" aria-expanded="true" style="padding: 10px 20px;">
                My Blog
              </button>
              <div class="collapse show" id="blog-collapse">
                <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                  <li><a href="add_blog.php"  class="link-body-emphasis d-inline-flex text-decoration-none rounded">Add Blog</a></li>
                  <li><a href="update_blog.php" class="link-body-emphasis d-inline-flex text-decoration-none rounded">Update Blog</a></li>
                  <li><a href="total_blog.php" class="link-body-emphasis d-inline-flex text-decoration-none rounded">Total Blogs</a></li>
                </ul>
              </div>
            </li>
            <li class="mb-1">
              <button class="btn btn-toggle d-inline-flex align-items-center rounded border-0 collapsed" data-bs-toggle="collapse" data-bs-target="#dashboard-collapse" aria-expanded="false">
              Manage User Account
              </button>
              <div class="collapse" id="dashboard-collapse">
                <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                  <li><a  onclick="add_user()" class="link-body-emphasis d-inline-flex text-decoration-none rounded">Add User</a></li>

                  <li><a  onclick="total_user()" class="link-body-emphasis d-inline-flex text-decoration-none rounded">Total Users</a></li>

                  <li><a  onclick="pending_user()" class="link-body-emphasis d-inline-flex text-decoration-none rounded">Pending Users</a></li>

                  <li><a  onclick="active_user()" class="link-body-emphasis d-inline-flex text-decoration-none rounded">Active Users</a></li>

                  <li><a  onclick="InActive_user()" class="link-body-emphasis d-inline-flex text-decoration-none rounded">InActive Users</a></li>

                  <li><a  onclick="update_user()" class="link-body-emphasis d-inline-flex text-decoration-none rounded">Update User</a></li>
                </ul>
              </div>
            </li>
            <li class="mb-1">
              <button class="btn btn-toggle d-inline-flex align-items-center rounded border-0 collapsed" data-bs-toggle="collapse" data-bs-target="#post-collapse" aria-expanded="false">
                My Post
              </button>
              <div class="collapse" id="post-collapse">
                <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                  <li><a href="add_post.php"  class="link-body-emphasis d-inline-flex text-decoration-none rounded">Add Post</a></li>
                  <li><a href="total_post.php" class="link-body-emphasis d-inline-flex text-decoration-none rounded">Total Posts</a></li>
                  <li><a href="update_post.php" class="link-body-emphasis d-inline-flex text-decoration-none rounded">Update Post</a></li>
                </ul>
              </div>
            </li>
             <li class="mb-1">
              <button class="btn btn-toggle d-inline-flex align-items-center rounded border-0 collapsed" data-bs-toggle="collapse" data-bs-target="#categories-collapse" aria-expanded="false">
                Categories
              </button>
              <div class="collapse" id="categories-collapse">
                <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                  <li><a href="add_category.php"  class="link-body-emphasis d-inline-flex text-decoration-none rounded">Add Category</a></li>
                  <li><a href="show_category.php" class="link-body-emphasis d-inline-flex text-decoration-none rounded">Show Categories</a></li>
                  <li><a href="update_category.php"  class="link-body-emphasis d-inline-flex text-decoration-none rounded">Update Category</a></li>
                </ul>
              </div>
            </li>
            <li class="mb-1">
              <button class="btn btn-toggle d-inline-flex align-items-center rounded border-0 collapsed" data-bs-toggle="collapse" data-bs-target="#feedback-collapse" aria-expanded="false">
                Feedback
              </button>
              <div class="collapse" id="feedback-collapse">
                <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                  <li><a href="show_feedback.php" class="link-body-emphasis d-inline-flex text-decoration-none rounded">Show Feedback</a></li>
                </ul>
              </div>
            </li>
            <li class="mb-1">
              <button class="btn btn-toggle d-inline-flex align-items-center rounded border-0 collapsed" data-bs-toggle="collapse" data-bs-target="#comment-collapse" aria-expanded="false">
                Comments
              </button>
              <div class="collapse" id="comment-collapse">
                <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                  <li><a href="show_comment.php" class="link-body-emphasis d-inline-flex text-decoration-none rounded">Show Comments</a></li>
                </ul>
              </div>
            </li>
            
            <li class="mb-1 border border-top border-light">
              <button class="btn btn-toggle d-inline-flex align-items-center rounded border-0 collapsed" data-bs-toggle="collapse" data-bs-target="#account-collapse" aria-expanded="false">
                Account
              </button>
              <div class="collapse" id="account-collapse">
                <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                  <li><a href="edit_admin_profile.php" class="link-body-emphasis d-inline-flex text-decoration-none rounded">Profile</a></li>
                  <li><a href="../logout.php"  class="link-body-emphasis d-inline-flex text-decoration-none rounded">Sign out</a></li>
                </ul>
              </div>
            </li>
          </ul>
      </div>
    </div>

    <div class="col-lg-10 my-2"id="show_response">
      <div class="row">
              <div class="col-md-4 my-3">
                  <div class="card h-100 bg-info">
                    <div class="card-body">
                      <h1 class="card-title"><img src="../images/admin_dashboard_images/post.png" height="80"></h1>
                      <h2 class="card-subtitle mb-2 text-decoration-none text-body-secondary"  >Total Posts</h2>
                      <h1 class="card-text text-center text-decoration-none" style="text-decoration: none;"><?php
                          $query = "SELECT COUNT(p.post_id) 'total_post' FROM post p JOIN blog b ON b.blog_id = p.blog_id INNER JOIN user u ON u.user_id = b.user_id WHERE u.user_id = '{$_SESSION['user']['user_id']}'";
                          $execute = $obj->execute_query($query);
                          if($execute->num_rows > 0){
                              while($row = mysqli_fetch_assoc($execute)){
                                  extract($row);
                              }
                            
                              echo $total_post;
                            
                          }
                           ?>
                         </h1>
                      <h4><a href="total_post.php" class="card-link text-center">Show Total Posts</a></h4>
                    </div>
                  </div>
              </div> 
               
              <div class="col-md-4 my-3"  >
                <div class="card h-100">
                    <div class="card-body bg-info">
                      <h1 class="card-title"><i class="fa-solid fa-list fa-2x"></i></h1>
                      <h2 class="card-subtitle mb-2 text-body-secondary">Total Categories</h2>
                      <h1 class="card-text text-center"> 
                          <?php
                          $query = "SELECT COUNT(c.category_id) 'total_category' FROM category c";
                          $execute = $obj->execute_query($query);
                          if($execute->num_rows > 0){
                              while($row = mysqli_fetch_assoc($execute)){
                                  extract($row);
                              }
                            
                              echo $total_category;
                            
                          }
                           ?>

                       </h1>
                      <h4><a href="show_category.php" class="card-link text-center">Show Total Categories</a></h4>
                    </div>
                </div>
              </div>
              <div class="col-md-4 my-3"  >
                <div class="card h-100">
                    <div class="card-body bg-info">
                      <h1 class="card-title"><i class="fa-solid fa-blog fa-2x"></i></h1>
                      <h2 class="card-subtitle mb-2 text-body-secondary">Total Blogs</h2>
                      <h1 class="card-text text-center">
                        <?php
                          $query = "SELECT COUNT(b.blog_id) 'total_blog' FROM blog b JOIN user u ON u.user_id = b.user_id WHERE u.user_id = '{$_SESSION['user']['user_id']}'";
                          $execute = $obj->execute_query($query);
                          if($execute->num_rows > 0){
                              while($row = mysqli_fetch_assoc($execute)){
                                  extract($row);
                              }
                            
                              echo $total_blog;
                            
                          }
                           ?>

                      </h1>
                      <h4><a href="total_blog.php" class="card-link text-center">Show Total blogs</a></h4>
                    </div>
                </div>
              </div>
      </div>

 
      <div class="row">
        <div class="col-md-4 my-3">
          <div class="card h-100">
              <div class="card-body bg-info">
                <h1 class="card-title"><i class="fa-regular fa-user fa-2x"></i></i></h1>
                <h2 class="card-subtitle mb-2 text-body-secondary">Total Users</h2>
                <h1 class="card-text text-center">
                     <?php
                          $query = "SELECT COUNT(u.user_id) 'total_user' FROM user u";
                          $execute = $obj->execute_query($query);
                          if($execute->num_rows > 0){
                              while($row = mysqli_fetch_assoc($execute)){
                                  extract($row);
                              }
                            
                              echo $total_user;
                            
                          }
                           ?>
                    
                 </h1>
                <h4><a href="#" onclick="total_user()" class="card-link text-center">Show Total Users</a></h4>
              </div>
          </div> 
        </div>
        <div class="col-md-4 my-3">
          <div class="card h-100">
              <div class="card-body bg-info">
                <h1 class="card-title"><i class="fa-solid fa-person-circle-question fa-2x"></i></i></h1>
                <h2 class="card-subtitle mb-2 text-body-secondary">User Request</h2>
                <h1 class="card-text text-center"> 

                   <?php
                          $query = "SELECT COUNT(u.user_id) 'pending_user' FROM user u WHERE u.is_approved = 'Pending'";
                          $execute = $obj->execute_query($query);
                          if($execute->num_rows > 0){
                              while($row = mysqli_fetch_assoc($execute)){
                                  extract($row);
                              }
                            
                              echo $pending_user;
                            
                          }
                           ?>

                 </h1>
                <h4><a href="#" onclick="pending_user()" class="card-link text-center">Show Total Request</a></h4>
              </div>
          </div>
        </div>
        <div class="col-md-4 my-3">
          <div class="card h-100">
              <div class="card-body bg-info">
                <h1 class="card-title"><i class="fa-regular fa-comment fa-2x"></i></i></h1>
                <h2 class="card-subtitle mb-2 text-body-secondary">Total Feedback</h2>
                <h1 class="card-text text-center"> 
                      <?php
                          $query = "SELECT COUNT(f.feedback_id) 'total_feedback' FROM user_feedback f";
                          $execute = $obj->execute_query($query);
                          if($execute->num_rows > 0){
                              while($row = mysqli_fetch_assoc($execute)){
                                  extract($row);
                              }
                            
                              echo $total_feedback;
                            
                          }
                           ?>
                       
                 </h1>
                <h4><a href="show_feedback.php" class="card-link text-center">Show Total Feedback</a></h4>
              </div>
          </div>
        </div>
      </div>
      
      <div class="row">  
        <div class="col-md-4 my-3">
          <div class="card h-100">
              <div class="card-body bg-info">
                <h1 class="card-title"><img src="../images/admin_dashboard_images/admin.png" class="img-fluid" style="height: 78px">
                <h2 class="card-subtitle mb-2 text-body-secondary">Total Admin</h2>
                <h1 class="card-text text-center"> 
                      
                      <?php
                          $query = "SELECT COUNT(u.user_id) 'total_admin' FROM user u WHERE u.role_id = 1";
                          $execute = $obj->execute_query($query);
                          if($execute->num_rows > 0){
                              while($row = mysqli_fetch_assoc($execute)){
                                  extract($row);
                              }
                            
                              echo $total_admin;
                            
                          }
                           ?>

                 </h1>
                <h4><a href="#" class="card-link text-center">Show Total Admin</a></h4>
              </div>
          </div>
        </div>
      </div>


    </div>
  </div>
</div>
<?php
include "require/footer.php";
?>