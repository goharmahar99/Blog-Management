<?php
include "../../database_file/database_setting.php";
include "../../database_file/database_driver.php";

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';
$obj = new database($hostname,$username,$password,$database);
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


$mail = new PHPMailer();

//Tell PHPMailer to use SMTP

$mail->SMTPOptions = array(
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    )
);
// $mail->SMTPDebug = SMTP::DEBUG_SERVER;  
$mail->isSMTP();
// Enable SMTP debugging
// SMTP::DEBUG_OFF = off (for production use)
// SMTP::DEBUG_CLIENT = client messages
//SMTP::DEBUG_SERVER = client and server messages

// $mail->SMTPDebug = SMTP::DEBUG_SERVER;


$mail->Host = 'smtp.gmail.com';
$mail->Port = 587;
$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
$mail->SMTPAuth = true;
$mail->Username = 'agmahar11@gmail.com';
$mail->Password = 'eohtkioqnbdlubxl';


if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'addUser'){
?>
<div class="row">
	<div class="col-md-2"></div>
	<div class="col-md-8">
	<h1 class="text-center text-light bg-dark bg-gradient rounded">Add User</h1>
	 
	<form action="../database_file/process.php" method="POST" class=""  enctype="multipart/form-data">
		<div class="mb-3">
		    <label  class="form-label">First Name</label>
		    <input type="text" class="form-control" name="first_name">
		</div>
		<div class="mb-3">
		    <label  class="form-label">Last Name</label>
		    <input type="text" class="form-control" name="last_name">
		</div>
		<div class="mb-3">
		    <label  class="form-label">Email</label>
		    <input type="email" class="form-control" name="email">
		</div>
		<div class="mb-3">
		    <label  class="form-label">Password</label>
		    <input type="password" class="form-control" name="password">
		</div>
        <div>
            <label  class="form-label">Role Type</label>
            <select class="form-select" aria-label="Default select example" name="role_type">
              <option value="">--Select Role--</option>
              <option value="1">Admin</option>
              <option value="2">User</option>
            </select>
        </div>    
		<div class="m-3">
		    <label class="form-label">Gender &nbsp;&nbsp;&nbsp;</label>
		    Male
		    <input class="form-check-input" type="radio" name="gender"  value="Male" >
		    Female
		    <input class="form-check-input" type="radio" name="gender"  value=" Female"> 
		</div>
		<div class="mb-3">
		    <label  class="form-label">Date Of Birth</label>
		    <input type="date" class="form-control" name="date_of_birth">
		</div>
		<div class="mb-3">
		    <label for="exampleFormControlTextarea1" class="form-label">Address</label>
		    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="  address"></textarea>
		</div>

		<div class="mb-3">
		    <label for="formFile" class="form-label">User Profile</label>
		    <input class="form-control" type="file" name="user_profile">
		</div>
        <input type="submit" name="admin_register" class="bg-primary text-light rounded border border-none fs-5" value="Register">
	</form>
  </div>
  <div class="col-md-2"></div>
</div>

<?php
}elseif(isset($_REQUEST['action']) && $_REQUEST['action'] == 'totalUser'){
    extract($_REQUEST);

    $query = "SELECT * FROM user";
    $execute = $obj->execute_query($query);

      
?>
<div class="row">
	<div class="col-md-12">
    <h1 class="text-center text-light bg-dark bg-gradient rounded">Total User</h1>
        
	    <table id="total-user" class="display" style="width:100%">
          <thead>
            <tr>
                <th>User Id</th>
                <th>User Image</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Password</th>
                <th>Gender</th>
                <th>Date of Birth</th>
                <th>Address</th>
                <th>User Status</th>
                <th>Is Active</th>
                <th>Created At</th>
                <th>Updated At</th>
            </tr>
          </thead>
          <tbody>
            <?php 
             if($execute->num_rows > 0){
                while ($row = mysqli_fetch_assoc($execute)) {
                      extract($row);
             ?>
            <tr>
                <td><?= $user_id?></td>
                <td><img src="../<?= $user_image?>" alt="" style="height: 50px;width: 50px;"></td>
                <td><?= $first_name." ".$last_name?></td>
                <td><?= $email?></td>
                <td><?= $password?></td>
                <td><?= $gender?></td>
                <td><?= $date_of_birth?></td>
                <td><?= $address?></td>
                <td><?= $is_approved?></td>
                <td><?= $is_active?></td>
                <td><?= $created_at?></td>
                <td><?= $updated_at?></td>
            </tr>

            <?php
              }
            }

            ?>
            

          </tbody>
        </table>
	</div>
</div>

<?php
}elseif(isset($_REQUEST['action']) && $_REQUEST['action'] == 'pendingUser'){
    extract($_REQUEST);

    $query = "SELECT * FROM user WHERE is_approved = 'Pending'";
    $execute = $obj->execute_query($query);

    if($execute->num_rows > 0){
      
?>
<div class="row">
	<div class="col-md-12">
    <h1 class="text-center text-light bg-dark bg-gradient rounded">Pending User</h1>

	    <table id="pending-user" class="display" style="width:100%">
          <thead>
            <tr>
                <th>User Id</th>
                <th>User Image</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Password</th>
                <th>Gender</th>
                <th>Date of Birth</th>
                <th>Address</th>
                <th>User Status</th>
                <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php 
              while($row = mysqli_fetch_assoc($execute)){
                extract($row);
            ?>
            <tr>
                <td><?= $user_id?></td>
                <td><img src="../<?= $user_image?>" alt="" style="height: 50px;width: 50px;"></td>
                <td><?= $first_name." ".$last_name?></td>
                <td><?= $email?></td>
                <td><?= $password?></td>
                <td><?= $gender?></td>
                <td><?= $date_of_birth?></td>
                <td><?= $address?></td>
                <td><?= $is_approved?></td>
                <td><button type="button" onclick="approve(<?=$user_id?>)" class="btn btn-success">Approve</button>
                  <button type="button" onclick="reject(<?=$user_id?>)" class="btn btn-danger">Reject</button>
                </td>
            </tr>

            <?php 
              }
            }else{
            ?>
       <h1 class="text-center text-light bg-secondary bg-gradient rounded">Not Record Found</h1>
             
            <?php
            }
            ?>
            

          </tbody>
        </table>
	</div>
</div>

<?php
}elseif(isset($_REQUEST['action']) && $_REQUEST['action'] == 'Approve'){
   extract($_REQUEST);
   $query = "UPDATE user SET is_approved = 'Approved',updated_at = Now() WHERE user_id = '{$user_id_}'";

   $execute = $obj->execute_query($query);
     if($execute){
    $query_2  = "SELECT * FROM user WHERE user_id ='{$user_id}'";
    $execute_2 = $obj->execute_query($query_2);

    if($execute_2->num_rows > 0){
        $row= mysqli_fetch_assoc($execute_2);
        extract($row);
      $mail->setFrom('agmahar11@gmail.com', 'Mr Abc');
      $mail->addReplyTo('agmahar11@gmail.com', 'Mr Abc');
      $mail->addAddress($email, $first_name.' '.$last_name);
      $mail->Subject = 'Registration Update';
      $mail->isHTML(true);
      $mail->Body = "<b style='color:green;'>Mr: '".$first_name.' '.$last_name."' Your Account Has Been Approved...!</b>";
       if (!$mail->send()) {
         echo 'Mailer Error: ' . $mail->ErrorInfo;
       }
    }


        echo $user_id;
       echo $obj->connection->affected_rows;
       echo "Ok";
     }

}elseif(isset($_REQUEST['action']) && $_REQUEST['action'] == 'Reject'){
   extract($_REQUEST);
     // print_r($_REQUEST);
   $query = "UPDATE user SET is_approved = 'Rejected',updated_at = Now() WHERE user_id = '{$user_id_}'";
   $execute = $obj->execute_query($query);
  if($execute){
      $query_2  = "SELECT * FROM user WHERE user_id ='{$user_id}'";
      $execute_2 = $obj->execute_query($query_2);

      if($execute_2->num_rows > 0){
        $row= mysqli_fetch_assoc($execute_2);
        extract($row);
      $mail->setFrom('agmahar11@gmail.com', 'Mr Abc');
      $mail->addReplyTo('agmahar11@gmail.com', 'Mr Abc');
      $mail->addAddress($email, $first_name.' '.$last_name);
      $mail->Subject = 'Registration Update';
      $mail->isHTML(true);
      $mail->Body = "<b style='color:red;'>Mr: '".$first_name.' '.$last_name."' Your Account Has Been Rejected...!</b>";
       if (!$mail->send()) {
         echo 'Mailer Error: ' . $mail->ErrorInfo;
       }

       }
        echo $user_id;
       echo $obj->connection->affected_rows;
       echo "Ok";
   }    
   
}elseif(isset($_REQUEST['action']) && $_REQUEST['action'] == 'activeUserStatus'){
    extract($_REQUEST);
     ?>

    <h1 class="text-center text-light bg-dark bg-gradient rounded">Active Users</h1>

    <?php
    $query = "SELECT * FROM user WHERE is_active = 'Active'";
    $execute = $obj->execute_query($query);

    if($execute->num_rows > 0){
      
?>
<div class="row">
    <div class="col-md-12">

        <table id="active-user" class="display" style="width:100%">
          <thead>
            <tr>
                <th>User Id</th>
                <th>User Image</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Password</th>
                <th>Gender</th>
                <th>Date of Birth</th>
                <th>Address</th>
                <th>Is_Active</th>
                <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php 
              while($row = mysqli_fetch_assoc($execute)){
                extract($row);
            ?>
            <tr>
                <td><?= $user_id?></td>
                <td><img src="../<?= $user_image?>" alt="" style="height: 50px;width: 50px;"></td>
                <td><?= $first_name." ".$last_name?></td>
                <td><?= $email?></td>
                <td><?= $password?></td>
                <td><?= $gender?></td>
                <td><?= $date_of_birth?></td>
                <td><?= $address?></td>
                <td><?= $is_active?></td>
                <td>
                  <button type="button" onclick="InActiveBtn(<?=$user_id?>)" class="btn btn-danger">In_Active</button>
                </td>
            </tr>
 
            <?php 
              }
            }else{
                ?>
        <h1 class="text-center text-light bg-secondary bg-gradient rounded">Record Not Found</h1>
           <?php
            }
            ?>
            

          </tbody>
        </table>
    </div>
</div>

<?php
}elseif(isset($_REQUEST['action']) && $_REQUEST['action'] == 'InActiveUserStatus'){
    extract($_REQUEST);
    ?>
    <h1 class="text-center text-light bg-dark bg-gradient rounded">In_Active Users</h1>

    <?php
    $query = "SELECT * FROM user WHERE is_active = 'InActive'";
    $execute = $obj->execute_query($query);

    if($execute->num_rows > 0){
      
?>
<div class="row">
    <div class="col-md-12">

        <table id="In_Active-user" class="display" style="width:100%">
          <thead>
            <tr>
                <th>User Id</th>
                <th>User Image</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Password</th>
                <th>Gender</th>
                <th>Date of Birth</th>
                <th>Address</th>
                <th>Is_Active</th>
                <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php 
              while($row = mysqli_fetch_assoc($execute)){
                extract($row);
            ?>
            <tr>
                <td><?= $user_id?></td>
                <td><img src="../<?= $user_image?>" alt="" style="height: 50px;width: 50px;"></td>
                <td><?= $first_name." ".$last_name?></td>
                <td><?= $email?></td>
                <td><?= $password?></td>
                <td><?= $gender?></td>
                <td><?= $date_of_birth?></td>
                <td><?= $address?></td>
                <td><?= $is_active?></td>
                <td>
                  <button type="button" onclick="ActiveBtn(<?=$user_id?>)" class="btn btn-success">Active</button>
                </td>
            </tr>

            <?php 
              }
            }else{
                ?>
        <h1 class="text-center text-light bg-secodary bg-gradient rounded">Record Not Found</h1>
           <?php
            }
            ?>
            

          </tbody>
        </table>
    </div>
</div>

<?php
}elseif(isset($_REQUEST['action']) && $_REQUEST['action'] =='ActiveBtn'){

      extract($_REQUEST);

    $query = "UPDATE user SET is_active = 'Active',updated_at = Now() WHERE user_id = '{$user_id}'";
    
    $execute = $obj->execute_query($query);
    if($execute){
      $query_2  = "SELECT * FROM user WHERE user_id ='{$user_id}'";
      $execute_2 = $obj->execute_query($query_2);

      if($execute_2->num_rows > 0){
        $row= mysqli_fetch_assoc($execute_2);
        extract($row);
      $mail->setFrom('agmahar11@gmail.com', 'Mr Abc');
      $mail->addReplyTo('agmahar11@gmail.com', 'Mr Abc');
      $mail->addAddress($email, $first_name.' '.$last_name);
      $mail->Subject = 'Registration Update';
      $mail->isHTML(true);
      $mail->Body = "<b style='color:green;'>Mr: '".$first_name.' '.$last_name."' Your Account Has Been Activated...!</b>";
       if (!$mail->send()) {
         echo 'Mailer Error: ' . $mail->ErrorInfo;
       }

       }
   echo $obj->connection->affected_rows;
     }
}elseif(isset($_REQUEST['action']) && $_REQUEST['action'] =='InActiveBtn'){

      extract($_REQUEST);

    $query = "UPDATE user SET is_active = 'InActive' WHERE user_id = '{$user_id}'";
    $execute = $obj->execute_query($query);
     if($execute){

      $query_2  = "SELECT * FROM user WHERE user_id ='{$user_id}'";
      $execute_2 = $obj->execute_query($query_2);

      if($execute_2->num_rows > 0){
        $row= mysqli_fetch_assoc($execute_2);
        extract($row);
      $mail->setFrom('agmahar11@gmail.com', 'Mr Abc');
      $mail->addReplyTo('agmahar11@gmail.com', 'Mr Abc');
      $mail->addAddress($email, $first_name.' '.$last_name);
      $mail->Subject = 'Registration Update';
      $mail->isHTML(true);
      $mail->Body = "<b style='color:red;'>Mr: '".$first_name.' '.$last_name."' Your Account Has Been InActivated...!</b>";
       if (!$mail->send()) {
         echo 'Mailer Error: ' . $mail->ErrorInfo;
       }

       }
      echo $obj->connection->affected_rows;
     }
}elseif(isset($_REQUEST['action']) && $_REQUEST['action'] == 'updateUser'){

    $query = "SELECT * FROM user ORDER BY user_id DESC";
    $execute = $obj->execute_query($query);

    if($execute->num_rows > 0){
      
?>
<div id="show_records">
  <div class="row">
    <div class="col-md-12">
    <h1 class="text-center text-light bg-dark bg-gradient rounded">Update User</h1>

        <table id="update-user" class="display" style="width:100%">
          <thead>
            <tr>
                <th>User Id</th>
                <th>User Image</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Password</th>
                <th>Gender</th>
                <th>Date of Birth</th>
                <th>Address</th>
                <th>Is_Active</th>
                <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php 
              while($row = mysqli_fetch_assoc($execute)){
                extract($row);

            ?>
            <tr>
                <td><?= $user_id?></td>
                <td><img src="../<?= $user_image?>" alt="" style="height: 50px;width: 50px;"></td>
                <td><?= $first_name." ".$last_name?></td>
                <td><?= $email?></td>
                <td><?= $password?></td>
                <td><?= $gender?></td>
                <td><?= $date_of_birth?></td>
                <td><?= $address?></td>
                <td><?= $is_active?></td>
                <td>
                  <button type="button" onclick="update_btn(<?=$user_id?>)" class="btn btn-success">Update</button>
                </td>
            </tr>

            <?php 
              }
        
            }
            ?>
            

          </tbody>
        </table>
    </div>
  </div>
</div>
<?php
}elseif(isset($_REQUEST['action']) && $_REQUEST['action'] == 'updatebtn'){
    extract($_REQUEST);

    $query = "SELECT * FROM user WHERE user_id = $User_Id";

    $execute = $obj->execute_query($query);
       $row = mysqli_fetch_assoc($execute);
       extract($row);
?>
<div class="row">
    <div class="col-md-2"></div>
    <div class="col-md-8">
    <h1 class="text-center text-light bg-dark bg-gradient rounded">Update User</h1>
     
    <form action="require/function_process.php" class="" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label  class="form-label">First Name</label>
            <input type="text" class="form-control" name="first_name" value="<?=$first_name??''?>">
        </div>
        <div class="mb-3">
            <label  class="form-label">Last Name</label>
            <input type="text" class="form-control" name="last_name" value="<?=$last_name??''?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Gender &nbsp;&nbsp;&nbsp;</label>
            Male
            <input class="form-check-input" type="radio" name="gender" id="gender" value="Male" 
             <?php 
               if(isset($gender)){
                   if($gender == 'Male'){
                     echo "Checked";
                   }
               }
              ?>
             >
            Female
            <input class="form-check-input" type="radio" name="gender" id="gender" value="Female"
             <?php 
               if(isset($gender)){
                   if($gender == 'Female'){
                     echo "Checked";
                   }
               }
              ?>

            > 
        </div>
        <div class="mb-3">
            <label  class="form-label">Date Of Birth</label>
            <input type="date" class="form-control" name="date_of_birth" value="<?=$date_of_birth??''?>">
        </div>
        <div class="mb-3">
            <label for="exampleFormControlTextarea1" class="form-label">Address</label>
            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="address"><?= $address??''?></textarea>
        </div>
          <input type="hidden" name="UserId" value="<?=$User_Id?>">
          <input type="hidden" name="profile" value="<?=$user_image??'';?>">

        <div class="mb-3">
            <label for="formFile" class="form-label">User Profile <span class="mx-5">previuos image <img src="../<?=$user_image?>" alt="" style="height: 50px;width: 50px;"></span></label>
            <input class="form-control" type="file" id="formFile" name="user_profile" value="">
        </div>
        <button type="submit"  name="update" value="update" class="btn btn-primary">Update</button>
    </form>
  </div>
  <div class="col-md-2"></div>
</div>

<?php
}elseif(isset($_REQUEST['update'])){
    extract($_REQUEST);



    $dir = "../../images";

      if(!(is_dir($dir))){
          if(!(mkdir($dir))){
             echo "$dir is not created";
          } 
      }
      
      $user_image = '';

      $file_name = rand().$_FILES['user_profile']['name'];
      $tmp_name = $_FILES['user_profile']['tmp_name'];

      $filepath = "images/user_image/".$file_name;
      move_uploaded_file($tmp_name, $filepath);

    if(isset($_FILES['user_profile']['name']) == ""){
      $img_path = $profile;
    }else{
      $img_path = $filepath;
    }

    $query = "UPDATE user SET first_name = '{$first_name}', last_name = '{$last_name}', gender = '{$gender}',date_of_birth = '{$date_of_birth}',address = '{$address}', user_image = '{$img_path}',updated_at = Now() WHERE user_id = $UserId";

    $execute = $obj->execute_query($query);
    
     if($execute){
         header("location: ../admin_dashboard.php?getusers"); 
     }
    

}elseif(isset($_REQUEST['action']) && $_REQUEST['action'] == 'addPost'){
?>
<div class="row">
	<div class="col-md-2"></div>
	<div class="col-md-8">
	  <h1 class="text-center text-light bg-dark bg-gradient rounded">Add Post</h1>
 
			<form action="">
			<div class="mb-3">
			  <label  class="form-label">Post Title</label>
			  <input type="text" class="form-control" name="post_title">
			</div>
			<div class="mb-3">
			  <label  class="form-label">Post Summary</label>
			  <input type="text" class="form-control" name="post_summary">
			</div>
			<div class="form-floating">
			  <textarea class="form-control" name="post_description" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px"></textarea>
			  <label for="floatingTextarea2">Post Description</label>
			</div>
			<div class="mb-3">
			  <label for="formFile" class="form-label">Featured Image</label>
			  <input class="form-control" type="file" id="formFile">
			</div>
            
            <div class="form-check form-switch d-flex">
              <label for="">Select Blog: &nbsp;</label>
              <input class="form-check-input mx-3" type="checkbox" role="switch" id="blog_1">
              <label class="form-check-label mx-3" for="flexSwitchCheckDefault">Blog 1</label>
              <input class="form-check-input mx-3" type="checkbox" role="switch" id="blog_2">
              <label class="form-check-label mx-3" for="flexSwitchCheckDefault">Blog 2</label>
            </div>




			<button type="submit" name="submit" class="btn btn-primary my-2">Add Post</button>
			</form>
  </div>
  <div class="col-md-2"></div>
</div>

<?php
}elseif(isset($_REQUEST['action']) && $_REQUEST['action'] == 'totalPost'){
?>
<div class="row">
	<div class="col-md-12">
    <h1 class="text-center text-light bg-dark bg-gradient rounded">Total Post</h1>

	    <table id="total-post" class="display" style="width:100%">
          <thead>
            <tr>
                <th>Post Id</th>
                <th>Blog Id</th>
                <th>Post Title</th>
                <th>Post Summary</th>
                <th>Post Description</th>
                <th>Featured Image</th>
                <th>Post Status</th>
                <th>Is Allowed</th>
                <th>Created At</th>
                <th>Updated At</th>
            </tr>
          </thead>
          <tbody>
            <tr>
                <td>1</td>
                <td>Im1</td>
                <td>Title 1</td>
                <td>Summary af ahsjf asdf</td>
                <td>ahdfakshf sajdhfaskdfh  sdhfhakjsj </td>
                <td>Image 1</td>
                <td>Active</td>
                <td>Yes</td>
                <td>8-3-2024 10:45 pm</td>
                <td>0:0:0: 0:0</td>
            </tr>
            <tr>
                <td>1</td>
                <td>1</td>
                <td>Title 1</td>
                <td>Summary af ahsjf asdf</td>
                <td>ahdfakshf sajdhfaskdfh  sdhfhakjsj </td>
                <td>Image 1</td>
                <td>Active</td>
                <td>Yes</td>
                <td>8-3-2024 10:45 pm</td>
                <td>0:0:0: 0:0</td>
            </tr>
            <tr>
                <td>1</td>
                <td>1</td>
                <td>Title 1</td>
                <td>Summary af ahsjf asdf</td>
                <td>ahdfakshf sajdhfaskdfh  sdhfhakjsj </td>
                <td>Image 1</td>
                <td>Active</td>
                <td>Yes</td>
                <td>8-3-2024 10:45 pm</td>
                <td>0:0:0: 0:0</td>
            </tr>
            <tr>
                <td>1</td>
                <td>Im1</td>
                <td>Title 1</td>
                <td>Summary af ahsjf asdf</td>
                <td>ahdfakshf sajdhfaskdfh  sdhfhakjsj </td>
                <td>Image 1</td>
                <td>Active</td>
                <td>Yes</td>
                <td>8-3-2024 10:45 pm</td>
                <td>0:0:0: 0:0</td>
            </tr>

          </tbody>
<!--           <tfoot>
            <tr>
                <th>User Id</th>
                <th>User Image</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Password</th>
                <th>Gender</th>
                <th>Date of Birth</th>
                <th>Address</th>
                <th>User Status</th>
                <th>Is Active</th>
                <th>Created At</th>
                <th>Updated At</th>
            </tr>
          </tfoot> -->
        </table>
	</div>
</div>

    <script type="text/javascript">
          	new DataTable('#example');
 
    </script>
<?php
}elseif(isset($_REQUEST['action']) && $_REQUEST['action'] == 'updatePost'){
?>
<div class="row">
	<div class="col-md-2"></div>
	<div class="col-md-8">
	  <h1 class="text-center text-light bg-dark bg-gradient rounded">Update Post</h1>
 
			<form action="">
			<div class="mb-3">
			  <label  class="form-label">Post Title</label>
			  <input type="text" class="form-control" name="post_title">
			</div>
			<div class="mb-3">
			  <label  class="form-label">Post Summary</label>
			  <input type="text" class="form-control" name="post_summary">
			</div>
			<div class="form-floating">
			  <textarea class="form-control" name="post_description" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px"></textarea>
			  <label for="floatingTextarea2">Post Description</label>
			</div>
			<div class="mb-3">
			  <label for="formFile" class="form-label">Featured Image</label>
			  <input class="form-control" type="file" id="formFile">
			</div>
			<button type="submit" name="submit" class="btn btn-primary">Submit</button>
			</form>
  </div>
  <div class="col-md-2"></div>
</div>

<?php
}elseif(isset($_REQUEST['action']) && $_REQUEST['action'] == 'addCategory'){
?>
<div class="row">
	<div class="col-md-2"></div>
	<div class="col-md-8">
	  <h1 class="text-center text-light bg-dark bg-gradient rounded">Add Category</h1>
			<form action="">
				    <div class="mb-3">
				  <label  class="form-label">Category Title</label>
				  <input type="text" class="form-control" name="category_title">
				</div>
				<div class="mb-3">
				 <label  class="form-label">Category Description</label>
				 	<input type="text" class="form-control" name="category_descrition">
				</div>
				<button type="submit" name="submit" class="btn btn-primary">Submit</button>
            </form>
    </div>
    <div class="col-md-2"></div>
</div>

<?php
}elseif(isset($_REQUEST['action']) && $_REQUEST['action'] == 'showCategory'){
?>
<div class="row">
	<div class="col-md-12">
    <h1 class="text-center text-light bg-dark bg-gradient rounded">Show Categories</h1>

	    <table id="show-category" class="display" style="width:100%">
          <thead>
            <tr>
                <th>Category Id</th>
                <th>Category Title</th>
                <th>Post Description</th>
                <th>Category Status</th>
                <th>Created At</th>
                <th>Updated At</th>
            </tr>
          </thead>
          <tbody>
            <tr>
                <td>1</td>
                <td>Category Title</td>
                <td>ahdfakshf sajdhfaskdfh  sdhfhakjsj </td>
                <td>Active</td>
                <td>8-3-2024 10:45 pm</td>
                <td>0:0:0: 0:0</td>
            </tr>
            <tr>
                <td>1</td>
                <td>Category Title</td>
                <td>ahdfakshf sajdhfaskdfh  sdhfhakjsj </td>
                <td>Active</td>
                <td>8-3-2024 10:45 pm</td>
                <td>0:0:0: 0:0</td>
            </tr>
            <tr>
                <td>1</td>
                <td>Category Title</td>
                <td>ahdfakshf sajdhfaskdfh  sdhfhakjsj </td>
                <td>Active</td>
                <td>8-3-2024 10:45 pm</td>
                <td>0:0:0: 0:0</td>
            </tr>
            <tr>
                <td>1</td>
                <td>Category Title</td>
                <td>ahdfakshf sajdhfaskdfh  sdhfhakjsj </td>
                <td>Active</td>
                <td>8-3-2024 10:45 pm</td>
                <td>0:0:0: 0:0</td>
            </tr>

          </tbody>
<!--           <tfoot>
            <tr>
                <th>User Id</th>
                <th>User Image</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Password</th>
                <th>Gender</th>
                <th>Date of Birth</th>
                <th>Address</th>
                <th>User Status</th>
                <th>Is Active</th>
                <th>Created At</th>
                <th>Updated At</th>
            </tr>
          </tfoot> -->
        </table>
	</div>
</div>

    <script type="text/javascript">
          	new DataTable('#example');
 
    </script>
<?php
}elseif(isset($_REQUEST['action']) && $_REQUEST['action'] == 'updateCategory'){
?>
<div class="row">
	<div class="col-md-2"></div>
	<div class="col-md-8">
	  <h1 class="text-center text-light bg-dark bg-gradient rounded">Update Category</h1>
			<form action="">
				    <div class="mb-3">
				  <label  class="form-label">Category Title</label>
				  <input type="text" class="form-control" name="category_title">
				</div>
				<div class="mb-3">
				 <label  class="form-label">Category Description</label>
				 	<input type="text" class="form-control" name="category_descrition">
				</div>
				<button type="submit" name="submit" class="btn btn-primary">Submit</button>
            </form>
    </div>
    <div class="col-md-2"></div>
</div>
<?php
}elseif(isset($_REQUEST['action']) && $_REQUEST['action'] == 'showFeedback'){
?>
<div class="row">
	<div class="col-md-12">
    <h1 class="text-center text-light bg-dark bg-gradient rounded">Show Feedback</h1>

	    <table id="show-feedback" class="display" style="width:100%">
          <thead>
            <tr>
                <th>Feedback Id</th>
                <th>User ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Feedback</th>
                <th>Created At</th>
            </tr>
          </thead>
          <tbody>
            <tr>
                <td>1</td>
                <td>1</td>
                <td>Ahmed Raza</td>
                <td>raza@gmail.com</td>
                <td>User Feedback</td>
                <td>8-3-2024 10:45 pm</td>
            </tr>
            <tr>
                <td>1</td>
                <td>1</td>
                <td>Ali Hamza</td>
                <td>hamza@gmail.com</td>
                <td>User Feedback</td>
                <td>8-3-2024 10:45 pm</td>
            </tr>
            <tr>
                <td>1</td>
                <td>1</td>
                <td>Ahmed Raza</td>
                <td>raza@gmail.com</td>
                <td>User Feedback</td>
                <td>8-3-2024 10:45 pm</td>
            </tr>
            <tr>
                <td>1</td>
                <td>1</td>
                <td>Ahmed Raza</td>
                <td>raza@gmail.com</td>
                <td>User Feedback</td>
                <td>8-3-2024 10:45 pm</td>
            </tr>

          </tbody>
<!--           <tfoot>
            <tr>
                <th>User Id</th>
                <th>User Image</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Password</th>
                <th>Gender</th>
                <th>Date of Birth</th>
                <th>Address</th>
                <th>User Status</th>
                <th>Is Active</th>
                <th>Created At</th>
                <th>Updated At</th>
            </tr>
          </tfoot> -->
        </table>
	</div>
</div>

    <script type="text/javascript">
          	new DataTable('#example');
 
    </script>
<?php
}


?>