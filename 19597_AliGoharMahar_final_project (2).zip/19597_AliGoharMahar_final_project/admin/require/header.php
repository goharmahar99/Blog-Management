<?php
session_start();
if(!(isset($_SESSION['user']))){
       header("location: ../login_form.php?show_msg=Please Login First&bg_color=red");
}elseif(isset($_SESSION['user']) && $_SESSION['user']['role_id'] == '2'){
       header("location: ../index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
		<!-- Bootstrap CSS -->
 

		<!-- Font-Awesome CSS -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
		<!-- Font-Awesome CSS -->

	<!-- Side Bar CSS & JS -->
	<link rel="stylesheet" href="sidebars.css">
	<script src="sidebars.js"></script>
	<!-- Side Bar CSS & JS  -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />


	<!-- Table CSS  -->
	<link rel="stylesheet" href="https://cdn.datatables.net/2.1.5/css/dataTables.dataTables.css">
	<!-- Table CSS  -->


	<title>Admin Dashboard</title>
	<style type="text/css">

		.nav-item:hover{
			background-color: lightblue;
			border-radius: 10px;
			border: none;
		}
	</style>
</head>
<body class="bg-secondary-subtle">
<div class="container-fluid">
  <header>
    <div class="container-fluid m-0 p-0 ">
    	<div class="row">
    		<div class="col-sm-12">

    		  <nav class="navbar navbar-expand-lg  bg-secondary rounded navigation">
				   <div class="container-fluid">

                  <img src=" https://cdn.logojoy.com/wp-content/uploads/2018/05/30164225/572-768x591.png" class="img-fluid rounded-pill" alt="..." style="height:50px">
				   
				    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				      <span class="navbar-toggler-icon"></span>
				    </button>
				    <div class="collapse navbar-collapse" id="navbarSupportedContent">
				      <ul class="navbar-nav me-auto mb-2 mb-lg-0 mx-3">
				        <li class="nav-item">
				          <a class="color nav-link active  text-light  mx-3 text-decoration-none " aria-current="page" href="../index.php">Goto Home Page</a>
				        </li>
				        <li class="nav-item">
				          <a class="nav-link  text-light  mx-3" href="admin_dashboard.php">Dashboard</a>
				        </li>
				          
				          </ul>
				        </li>
				      </ul>

                    <div class="dropdown">
										<button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">									  
										<span class="text-light"><?= $_SESSION['user']['first_name']." ".$_SESSION['user']['last_name']??''; ?></span>
										</button>
										<ul class="dropdown-menu">
										  <li><a class="dropdown-item" href="edit_admin_profile.php">Edit Profile</a></li>
										  <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
										</ul>
                    </div>
                      <img src="../<?= $_SESSION['user']['user_image'];?>" class="img-fluid rounded-pill px-1" alt="..." style="height:50px">


               

				    </div>
				  </div>
				</nav>
    		</div>
    	</div>
    </div>
</header>