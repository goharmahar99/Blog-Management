
<footer>
    <div class="container-fluid bg-secondary mt-5 text-light">
    	<div class="row">
			  <div class="col-sm-6">
			  	<h1>Social Media</h1>
			  	 <ul  style="list-style: none;">
			  	 	<li><i class="fa-brands fa-facebook" style="height: 30; width: 30; padding-right: 10px;"></i><a class="text-light" href="">facebook</a></li>
			  	 	<li><i style="padding-right: 10px;" class="fa-brands fa-instagram"></i><a href="" class="text-light">instagram</a></li>
			  	 	<li><i style="padding-right: 10px;" class="fa-brands fa-square-twitter"></i><a href="" class="text-light">twitter</a></li>
			  	 	<li><i style="padding-right: 10px;" class="fa-brands fa-linkedin"></i><a href="" class="text-light">linkedin</a></li>
			  	 </ul>
			  </div>

			  <div class="col-sm-6">
			  	<h1>Contact Us</h1>
			  	  <p><i class="fa-regular fa-envelope"></i> abc@gmail.com</p>
			  	  <p><i class="fa-solid fa-phone"></i> 123+ 234 2323424</p>
			  	  <p><i class="fa-solid fa-house"></i> Flat No: 23 XYZ</p>
			  </div>
		</div>
	</div>		
</footer>
		<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
		<!-- Bootstrap JS -->
 
		
  		<!-- Data Table JS -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>    
    <script src="https://cdn.datatables.net/2.1.6/js/dataTables.js"></script>    
		<!-- Data Table JS -->
        
    <script type="text/javascript">
    	new DataTable('#tables');
     </script> 
    
<script src="require/functions.js"></script>
<?php 
	if (isset($_REQUEST['getusers'])) {
?>
	<script>
		update_user();

	</script>
<?php
	}elseif(isset($_REQUEST['add_user'])){
     ?>
	<script>
		add_user();

	</script>
<?php
	}elseif(isset($_REQUEST['show_msg'])){
    ?>
        <script>
           setTimeout(function(){
            document.getElementById('show_msg').style.display= 'none';
            },5000);
        </script>
   <?php
	}
 ?>



</body>
</html>