

/*-----Manage User-----*/


function add_user(){
 var show_response = document.getElementById('show_response');
 var obj = new XMLHttpRequest();
 obj.onreadystatechange = function(){
   if(obj.readyState == 4 && obj.status == 200){
       document.getElementById('show_response').innerHTML = obj.responseText;
       
   }
 }
 obj.open("GET","require/function_process.php?action=addUser");
 obj.send();

}

function total_user(){
 var show_response = document.getElementById('show_response');
 var obj = new XMLHttpRequest();
 obj.onreadystatechange = function(){
   if(obj.readyState == 4 && obj.status == 200){
       document.getElementById('show_response').innerHTML = obj.responseText;
       new DataTable('#total-user');

   }
 }
 obj.open("GET","require/function_process.php?action=totalUser");
 obj.send();

}

function pending_user(){
 var show_response = document.getElementById('show_response');
 var obj = new XMLHttpRequest();
 obj.onreadystatechange = function(){
   if(obj.readyState == 4 && obj.status == 200){
       document.getElementById('show_response').innerHTML = obj.responseText;
       new DataTable('#pending-user');

   }
 }
 obj.open("GET","require/function_process.php?action=pendingUser");
 obj.send();

}

function approve(user_id){
    //alert(user_id);
 var show_response = document.getElementById('show_response');
 var obj = new XMLHttpRequest();
 obj.onreadystatechange = function(){
      
      if(obj.readyState == 4 && obj.status == 200){
     // document.getElementById('show_response').innerHTML = obj.responseText;
      console.log(obj.responseText);
       // new DataTable('#pending-user');
       pending_user();
   }
 }
 obj.open("GET","require/function_process.php?action=Approve&user_id ="+user_id);
 obj.send();  
}


function reject(user_id){
 var show_response = document.getElementById('show_response');
 var obj = new XMLHttpRequest();
 obj.onreadystatechange = function(){
      
      if(obj.readyState == 4 && obj.status == 200){
     // document.getElementById('show_response').innerHTML = obj.responseText;
      console.log(obj.responseText);
       // new DataTable('#pending-user');
       pending_user();
   }
 }
 obj.open("GET","require/function_process.php?action=Reject&user_id ="+user_id);
 obj.send();  
}


function active_user(){
 var show_response = document.getElementById('show_response');
 var obj = new XMLHttpRequest();
 obj.onreadystatechange = function(){
   if(obj.readyState == 4 && obj.status == 200){
       document.getElementById('show_response').innerHTML = obj.responseText;
       new DataTable('#active-user');

   }
 }
 obj.open("GET","require/function_process.php?action=activeUserStatus");
 obj.send();

}

function InActive_user(){
 var show_response = document.getElementById('show_response');
 var obj = new XMLHttpRequest();
 obj.onreadystatechange = function(){
   if(obj.readyState == 4 && obj.status == 200){
       document.getElementById('show_response').innerHTML = obj.responseText;
       new DataTable('#In_Active-user');

   }
 }
 obj.open("GET","require/function_process.php?action=InActiveUserStatus");
 obj.send();

}


function ActiveBtn(user_id){
   // alert(user_id);
 var show_response = document.getElementById('show_response');
 var obj = new XMLHttpRequest();
 obj.onreadystatechange = function(){
   if(obj.readyState == 4 && obj.status == 200){

     console.log(obj.responseText);
     InActive_user();
   }
 }
 obj.open("GET","require/function_process.php?action=ActiveBtn&user_id="+user_id);
 obj.send();

}


function InActiveBtn(user_id){
   // alert(user_id);
 var show_response = document.getElementById('show_response');
 var obj = new XMLHttpRequest();
 obj.onreadystatechange = function(){
   if(obj.readyState == 4 && obj.status == 200){

     console.log(obj.responseText);
      active_user();
   }
 }
 obj.open("GET","require/function_process.php?action=InActiveBtn&user_id="+user_id);
 obj.send();

}




function update_user(){
 var show_response = document.getElementById('show_response');
 var obj = new XMLHttpRequest();
 obj.onreadystatechange = function(){
   if(obj.readyState == 4 && obj.status == 200){
       document.getElementById('show_response').innerHTML = obj.responseText;
       new DataTable('#update-user');

   }
 }
 obj.open("GET","require/function_process.php?action=updateUser");
 obj.send();

}


function update_btn(user_id){
   // alert(user_id);
    // var show_response = document.getElementById('');
   var obj = new XMLHttpRequest();
 obj.onreadystatechange = function(){
   if(obj.readyState == 4 && obj.status == 200){
      document.getElementById('show_response').innerHTML = obj.responseText;
    // console.log(document.getElementById('udpate_form'));
   }
 }
 obj.open("GET","require/function_process.php?action=updatebtn&User_Id="+user_id);
 obj.send();  
}


function update(){
   // alert(user_id);
  var show_response = document.getElementById('show_response');
   var obj = new XMLHttpRequest();
 obj.onreadystatechange = function(){
   if(obj.readyState == 4 && obj.status == 200){
      //document.getElementById('show_response').innerHTML = obj.responseText;
        console.log(document.getElementById('show_response'));
   }
 }
 obj.open("GET","require/function_process.php?action=update");
 obj.send();  
}
/*-----Manage User-----*/




function add_post(){
 var show_response = document.getElementById('show_response');
 var obj = new XMLHttpRequest();
 obj.onreadystatechange = function(){
   if(obj.readyState == 4 && obj.status == 200){
       document.getElementById('show_response').innerHTML = obj.responseText;
   }
 }
 obj.open("GET","require/function_process.php?action=addPost");
 obj.send();

}

function total_post(){
 var show_response = document.getElementById('show_response');
 var obj = new XMLHttpRequest();
 obj.onreadystatechange = function(){
   if(obj.readyState == 4 && obj.status == 200){
       document.getElementById('show_response').innerHTML = obj.responseText;
       new DataTable('#total-post');

   }
 }
 obj.open("GET","require/function_process.php?action=totalPost");
 obj.send();

}

function update_post(){
 var show_response = document.getElementById('show_response');
 var obj = new XMLHttpRequest();
 obj.onreadystatechange = function(){
   if(obj.readyState == 4 && obj.status == 200){
       document.getElementById('show_response').innerHTML = obj.responseText;
   }
 }
 obj.open("GET","require/function_process.php?action=updatePost");
 obj.send();

}

function add_category(){
 var show_response = document.getElementById('show_response');
 var obj = new XMLHttpRequest();
 obj.onreadystatechange = function(){
   if(obj.readyState == 4 && obj.status == 200){
       document.getElementById('show_response').innerHTML = obj.responseText;
   }
 }
 obj.open("GET","require/function_process.php?action=addCategory");
 obj.send();

}

function show_categories(){
 var show_response = document.getElementById('show_response');
 var obj = new XMLHttpRequest();
 obj.onreadystatechange = function(){
   if(obj.readyState == 4 && obj.status == 200){
       document.getElementById('show_response').innerHTML = obj.responseText;
       new DataTable('#show-category');

   }
 }
 obj.open("GET","require/function_process.php?action=showCategory");
 obj.send();

}

function update_category(){
 var show_response = document.getElementById('show_response');
 var obj = new XMLHttpRequest();
 obj.onreadystatechange = function(){
   if(obj.readyState == 4 && obj.status == 200){
       document.getElementById('show_response').innerHTML = obj.responseText;
   }
 }
 obj.open("GET","require/function_process.php?action=updateCategory");
 obj.send();

}

function show_feedback(){
 var show_response = document.getElementById('show_response');
 var obj = new XMLHttpRequest();
 obj.onreadystatechange = function(){
   if(obj.readyState == 4 && obj.status == 200){
       document.getElementById('show_response').innerHTML = obj.responseText;
       new DataTable('#show-feedback');

   }
 }
 obj.open("GET","require/function_process.php?action=showFeedback");
 obj.send();

}









