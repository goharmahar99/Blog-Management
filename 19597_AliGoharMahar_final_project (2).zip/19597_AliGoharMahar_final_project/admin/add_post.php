<?php
include "require/header.php";
include "sidebar.php";
include "../database_file/database_setting.php";
include "../database_file/database_driver.php";

$obj = new database($hostname,$username,$password,$database);
?>
<div class="col-lg-10 my-3" id="show_response">
	
 <div class="row">
	<div class="col-md-2"></div>
	<div class="col-md-8">
	  <h1 class="text-center text-light bg-dark bg-gradient rounded">Add Post</h1>
           <?php 

           if(isset($_REQUEST['msg'])){
           ?>
           <p id="show_msg" class="text-center text-light rounded" style="background-color: <?=$_REQUEST['bg_color']?>;"><?=$_REQUEST['msg']?></p>

           <?php
            }

           ?>
			<form action="post_process.php" method="POST" enctype="multipart/form-data">
			<div class="mb-3">
			  <label  class="form-label">Post Title:</label>
			  <input type="text" class="form-control" name="post_title" required>
			</div>
			<div class="mb-3">
			  <label  class="form-label">Post Summary:</label>
			  <input type="text" class="form-control" name="post_summary" required>
			</div>
			<div class="form-floating">
			  <textarea class="form-control" name="post_description" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px" required></textarea>
			  <label for="floatingTextarea2">Post Description</label>
			</div>
             
            <?php 
            $query = "SELECT * FROM blog"; 
            $execute = $obj->execute_query($query);
            if($execute->num_rows > 0){
            
            ?>

            <select class="form-select my-3" name="blog" aria-label="Default select example" required>
               <option selected>Choose Blog</option>
		    <?php
		      while($row = mysqli_fetch_assoc($execute)){
		                   extract($row);
		      ?>
            <option value="<?= $blog_id?>"><?=$blog_title?></option>
		      <?php 
		       }
		      ?>
           </select>
	    <?php 
	      }else{
	      	?>
              <select class="form-select my-2" name="blog" aria-label="Default select example">
              <option selected>No blog found please add blog</option>
              </select>
	      	<?php
	      }
           
            $query = "SELECT * FROM category"; 
            $execute = $obj->execute_query($query);
            if($execute->num_rows > 0){
            
            ?>

            <select class="form-select my-3" name="category[]" required multiple>
		    <?php
		      while($row = mysqli_fetch_assoc($execute)){
		                   extract($row);
		      ?>
            <option value="<?= $category_id?>"><?=$category_title?></option>
		      <?php 
		       }
		      ?>
           </select>
	    <?php 
	      }else{
	      	?>
              <select class="form-select my-2" name="category" aria-label="Default select example">
              <option selected>No category found please add category</option>
              </select>
	      	<?php
	      }
	    ?>




	        <p class="my-2 fw-bold">Post Status:</p>
            <div class="form-check">
                  <input class="form-check-input" type="radio" name="post_status" value="Active" required>
                  <label class="form-check-label" for="flexRadioDefault1">
                    Active
                  </label>
            </div>

            <div class="form-check">
                  <input class="form-check-input" type="radio" name="post_status" value="InActive" required>
                  <label class="form-check-label" for="flexRadioDefault1">
                    InActive
                   </label>
            </div>


            <p class="my-2 fw-bold">Comment Permission:</p>
            <div class="form-check">
                  <input class="form-check-input" type="radio" name="is_comment_allowed" value="1" required>
                  <label class="form-check-label" for="flexRadioDefault1">
                    Comment Allowed
                  </label>
            </div>

            <div class="form-check">
                  <input class="form-check-input" type="radio" name="is_comment_allowed" value="0" required>
                  <label class="form-check-label" for="flexRadioDefault1">
                    Comment Not Allowed
                   </label>
            </div>


			<div class="mb-3 my-2">
			  <label for="formFile" class="form-label">Featured Image:</label>
			  <input class="form-control" name="featured_img" type="file" required>
			</div>


            <div class="mb-3">
			  <label  class="form-label">No: of Attachment:</label>
			  <input type="number" class="form-control" name="no_of_attachment" min="1">
			</div>             


            <div>
            <button type="submit" name="add_post" class="btn btn-primary my-2">Add Post</button>
			</form>
		    </div>
  
  <div class="col-md-2"></div>
 </div>
</div>



<?php
include "require/footer.php";
?>