<?php
include "require/header.php";
include "sidebar.php";
include "../database_file/database_setting.php";
include "../database_file/database_driver.php";

$obj = new database($hostname,$username,$password,$database);

?>

<div class="col-lg-10 my-3 table-responsive" id="show_response">
 <div class="row">
    <div class="col-md-12">
    <h1 class="text-center text-light bg-dark bg-gradient rounded">Total Posts</h1>
          <?php
           $query = "SELECT p.*,b.blog_title FROM post p join blog b ON p.blog_id = b.blog_id";
            $execute = $obj->execute_query($query);

            if($execute->num_rows > 0){
          ?>
        <table id="tables" class="display" style="width:100%">
          <thead>
            <tr>
                <th>Post Id</th>
                <th>Blog Title</th>
                <th>Post Title</th>
                <th>Post Summary</th>
                <th>Post Description</th>
                <th>Featured Image</th>
                <th>Post Status</th>
                <th>View Comment</th>
                <th>Is_Comment_Allowed</th>
                <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php 
             while($row = mysqli_fetch_assoc($execute)) {
                extract($row); 
             ?>
            <tr>
                <td><?= $post_id?></td>
                <td><?= $blog_title?></td>
                <td><?= substr($post_title,0,100)?></td>
                <td><?= substr($post_summary, 0,50)?></td>
                <td><?= substr($post_description,0,80)?></td>
                <td><img src="../<?= $featured_image?>" style="height: 50px; width: 50px;"></td>
                <td><?= $post_status?></td>
                <td><a href="view_post_comment.php?post_id=<?=$post_id?>">View Comment</a></td>
                <td><?= $is_comment_allowed?></td>
                <td>
                    <?php 
                      if($post_status == 'Active'){
                          ?>
                        <a class="btn btn-danger" href="process.php?action=Post_InActive&post_id=<?=$post_id?>">InAcive</a>
                        <?php 
                         }else{
                          ?>
                            <a class="btn btn-success" href="process.php?action=Post_Active&post_id=<?=$post_id?>">Active</a>
                          <?php
                         }
                         ?>
                       </td>
                      
            </tr>
            
             <?php } ?>
          </tbody>
        </table>
    <?php } ?>
    </div>
 </div>
</div>




<?php
include "require/footer.php";
?>