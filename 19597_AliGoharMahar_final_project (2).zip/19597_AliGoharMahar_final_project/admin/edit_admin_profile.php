<?php
include "require/header.php";
include "../database_file/database_setting.php";
include "../database_file/database_driver.php";

$obj = new database($hostname,$username,$password,$database);
 $query = "SELECT * FROM user WHERE user_id = '{$_SESSION['user']['user_id']}'";
   $execute = $obj->execute_query($query);
   if($execute->num_rows > 0){
       $row = mysqli_fetch_assoc($execute);
       extract($row);   
?>
<div class="container">
	<div class="row">
		<div class="col-sm-12">
			<div class="row">
				<div class="col-sm-3"></div>
				<div class="col-sm-6">
				  <form method="POST" action="../database_file/process.php" enctype="multipart/form-data" >
             <center>
  
				  	<div class="rounded-pill my-3 border border-dark justify-align-center" style="height: 100px; width: 100px;">
				  	<img src="../<?=$user_image?>" class="img-fluid rounded-pill" style="height: 100px; width:100px">
             </div>
             </center>
             <input type="hidden" name="previous_image" value="<?=$user_image?>">
					<div class="mb-3">
					    <label  class="form-label">First Name</label>
					    <input type="text" class="form-control" name="first_name" id="first_name" value="<?=$first_name?>" style="outline:<?= (isset($_SESSION['first_name_msg'])?'1px solid red':'')?>;">
					    <p id="first_name_msg" class="text-center text-danger"><?=$_SESSION['first_name_msg']??''?></p>
					</div>

					<div class="mb-3">
					    <label  class="form-label">Last Name</label>
					    <input type="text" class="form-control" name="last_name" id="last_name" value="<?=$last_name?>" style="outline:<?= (isset($_SESSION['last_name_msg'])?'1px solid red':'')?>;">
					    <p id="last_name_msg" class="text-center text-danger"><?=$_SESSION['last_name_msg']??''?></p>
					</div>

					<div class="mb-3">
					    <label  class="form-label">Email</label>
					    <input type="email" class="form-control" name="email" id="email" value="<?=$email?>" style="outline:<?= (isset($_SESSION['email_msg'])?'1px solid red':'')?>;">
					    <p id="email_msg" class="text-center text-danger"><?=$_SESSION['email_msg']??''?></p>
					</div>

					<div class="mb-3">
					    <label  class="form-label">Password</label>
					    <input type="password" class="form-control" name="password" id="password" value="<?=$password?>" style="outline:<?= (isset($_SESSION['password_msg'])?'1px solid red':'')?>;">
					    <p id="password_msg" class="text-center text-danger"><?=$_SESSION['password_msg']??''?></p>
					</div>

					<div class="mb-3">
					    <label class="form-label">Gender &nbsp;&nbsp;&nbsp;</label>
					    Male
					    <input class="form-check-input" type="radio" name="gender" value="Male"
                        <?php
					    if(isset($gender)){
                           if($gender == 'Male'){
                             echo "checked";
                           }
                         }
                        ?>
					    >
					    Female
					    <input class="form-check-input" type="radio" name="gender" value="Female"
                        <?php
					    if(isset($gender)){
                           if($gender == 'Female'){
                             echo "checked";
                           }
                         }
                        ?>
					    >
					    <span id="gender_msg" class="text-center text-danger ml-5"><?=$_SESSION['gender_msg']??''?></span> 
					</div>

					<div class="mb-3">
					    <label  class="form-label">Date Of Birth</label>
					    <input type="date" class="form-control" name="date_of_birth" id="date_of_birth" value="<?=$date_of_birth?>"style="outline:<?= (isset($_SESSION['date_of_birth_msg'])?'1px solid red':'')?>;">
			            <p id="date_of_birth_msg" class="text-center text-danger"><?=$_SESSION['date_of_birth_msg']??''?></p>
					</div>


					<div class="mb-3">
					    <label for="exampleFormControlTextarea1" class="form-label">Address</label>
					    <textarea class="form-control"  rows="3" name="address" id="address" style="outline:<?= (isset($_SESSION['address_msg'])?'1px solid red':'')?>;"><?=$address?></textarea>
			            <p id="address_msg" class="text-center text-danger"><?=$_SESSION['address_msg']??''?></p>
					</div>
                          <input type="hidden" name="previous_image" value="<?=$user_image?>">
					<div class="mb-3">

					    <label for="formFile" class="form-label">New User Profile </label>
					    <input class="form-control" type="file" id="formFile" name="user_profile" style="outline:<?= (isset($_SESSION['formFile_msg'])?'1px solid red':'')?>;">
			            <p id="formFile_msg" class="text-center text-danger"><?=$_SESSION['formFile_msg']??''?></p>
					</div>

					<input type="submit" name="edit_user_profile" class="bg-primary text-light rounded border border-none fs-5" value="Update">
	              </form>
				</div>
				<div class="col-sm-3"></div>
			</div>
		</div>
	</div>
</div>

<?php 
}

   
include "require/footer.php";
?>