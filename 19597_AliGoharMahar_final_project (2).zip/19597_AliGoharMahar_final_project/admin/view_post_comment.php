<?php
include "require/header.php";
include "sidebar.php";
include "../database_file/database_setting.php";
include "../database_file/database_driver.php";

$obj = new database($hostname,$username,$password,$database);
extract($_REQUEST);
?>
  
<div class="col-lg-10 my-3 table-responsive" id="show_response">
 <div class="row">
    <div class="col-md-12">
          <?php
          $query = "SELECT pc.*,p.post_title,CONCAT(u.first_name,' ',u.last_name) 'full_name' FROM user u JOIN post_comment pc ON u.user_id = pc.user_id INNER JOIN post p ON pc.post_id = p.post_id WHERE pc.post_id = '{$post_id}'";
          $execute = $obj->execute_query($query);

        if($execute->num_rows > 0){
          ?>
    <h1 class="text-center text-light bg-dark bg-gradient rounded">Post Comment</h1>
        <table id="tables" class="display" style="width:100%">
          <thead>
            <tr>
                <th>Comment Id</th>
                <th>Post Title</th>
                <th>User Name</th>
                <th>Comment</th>
                <th>Is_Active</th>
                <th>Created_at</th>
                <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php 
             while($row = mysqli_fetch_assoc($execute)) {
                extract($row); 
             ?>
            <tr>
                <td><?= $post_comment_id?></td>
                <td><?= $post_title?></td>
                <td><?= $full_name?></td>
                <td><?= $comment?></td>
                <td><?= $is_active?></td>
                <td><?= $created_at?></td>
                <td>
                    <?php 
                      if($is_active == 'Active'){
                          ?>
                        <a class="btn btn-danger" href="process.php?action=Comment_InActive&post_id=<?=$post_id?>&comment_id=<?=$post_comment_id?>">InAcive</a>
                        <?php 
                         }else{
                          ?>
                            <a class="btn btn-success" href="process.php?action=Comment_Active&post_id=<?=$post_id?>&comment_id=<?=$post_comment_id?>">Active</a>
                          <?php
                         }
                         ?>
                       </td>
                      
            </tr>
            
             <?php } ?>
          </tbody>
        </table>
    <?php }else{
      ?>
          <h1 class="text-center text-light bg-secondary bg-gradient rounded">No Comment Record</h1>
        
      <?php
    } ?>
    </div>
 </div>
</div>




<?php
include "require/footer.php";
?>