<?php
include "require/header.php";
include "sidebar.php";
include "../database_file/database_setting.php";
include "../database_file/database_driver.php";

$obj = new database($hostname,$username,$password,$database);

?>
<div class="col-lg-10 my-3" id="show_response">
 <div class="row">
	<div class="col-md-2"></div>
	<div class="col-md-8">
	  <h1 class="text-center text-light bg-dark bg-gradient rounded">Add Category</h1>

	     <?php  
        if(isset($_REQUEST['msg'])){
        ?>
         <p id="show_msg" class="text-light text-center rounded" style="background-color:<?=$_REQUEST['bg_color']?>;"><?= $_REQUEST['msg']?></p>
        <?php
        }

	     ?>
 
			<form action="process.php" method="POST">
			<div class="mb-3">
			  <label  class="form-label">Category Title</label>
			  <input type="text" class="form-control" name="category_title" required>
			</div>

			<div class="form-floating">
			  <textarea class="form-control" name="category_description" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px" required></textarea>
			  <label for="floatingTextarea2">Category Description</label>
			</div>


	        <p class="my-2 fw-bold">Category Status</p>
            <div class="form-check">
                  <input class="form-check-input" type="radio" name="category_status" value="Active" required>
                  <label class="form-check-label" for="flexRadioDefault1">
                    Active
                  </label>
            </div>

            <div class="form-check">
                  <input class="form-check-input" type="radio" name="category_status" value="InActive" required>
                  <label class="form-check-label" for="flexRadioDefault1">
                    InActive
                   </label>
            </div>
            
            <button type="submit" name="add_category" class="btn btn-primary my-2">Add Category</button>
			</form>
  </div>
  <div class="col-md-2"></div>
 </div>
</div>





<?php
include "require/footer.php";
?>