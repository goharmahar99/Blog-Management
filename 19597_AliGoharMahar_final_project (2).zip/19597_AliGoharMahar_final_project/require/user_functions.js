
function card_1(){
  // alert("Ok");
  //console.log("Ok");
  var obj = new XMLHttpRequest();

  obj.onreadystatechange = function(){
    if(obj.readyState == 4 && obj.status == 200){
       document.getElementById('user_response').innerHTML = obj.responseText;
    }

  }

  obj.open("GET","require/user_function_process.php?action=card1");
  obj.send();
}


