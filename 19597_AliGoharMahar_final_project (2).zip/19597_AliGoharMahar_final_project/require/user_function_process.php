<?php
if(isset($_REQUEST['action']) && $_REQUEST['action']=='card1'){
?>
  <div class="row">
  	<div class="col-md-2"></div>
  	<div class="col-md-8">
	    <div class="card w-100" style="width: 18rem;">
			    <img src="https://cdn.pixabay.com/photo/2019/11/29/09/46/garden-4660938_640.jpg" class="card-img-top" alt="..." height="400">
				<div class="card-body">
					<h5 class="card-title">Card title</h5>
					<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content. Lorem ipsum, dolor sit amet consectetur adipisicing elit. Aut tenetur deleniti error, unde odio ducimus nulla quod nesciunt perferendis tempora optio rerum! Nostrum, repellendus facilis non unde iure itaque sunt cum iusto nulla at deleniti. Fuga hic voluptate, quas ad, esse assumenda omnis dolore quod!</p>
				</div>
		</div>

	    <div class="card">
          <div class="card-body">
             <form action="">
                <div class="form-floating">
				    <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea"></textarea>
						<label for="floatingTextarea">Comments</label>
				</div>
					<button type="submit" name="submit" class="btn btn-primary my-2">Submit</button>
					<button type="submit" name="show_comment" class="btn btn-primary my-2">Show All Comment</button>
			 </form>
           </div>
        </div>

            <p class="my-5">Change Theme Setting 

            <!-- Button trigger modal -->
			    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
					  Change Theme
				</button>

				<!-- Modal -->
			<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
			    <div class="modal-dialog">
				    <div class="modal-content">
				      <div class="modal-header">
				        <h1 class="modal-title fs-5" id="exampleModalLabel">Change Theme</h1>
				        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				      </div>
					    <div class="modal-body">
					        <div class="mb-3">
							    <label  class="form-label">Setting Key</label>
							    <input type="text" class="form-control" name="setting_key">
						    </div>
									<div class="mb-3">
									  <label for="exampleFormControlTextarea1" class="form-label">Setting Value</label>
									  <input type="text" class="form-control" name="setting_value">
									</div>
					        </div>
					      <div class="modal-footer">
					        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
					        <button type="submit" name="submit" class="btn btn-primary">Submit</button>
					      </div>
					    </div>
					  </div>
					</div>

                   </p>
            </div>	
	    </div>
    </div>
  	<div class="col-md-2"></div>

  </div>

<?php
}



?>