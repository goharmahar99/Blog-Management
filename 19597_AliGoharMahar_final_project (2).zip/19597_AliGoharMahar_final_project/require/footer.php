
<footer>
    <div class="container-fluid bg-secondary mt-5 text-light">
    	<div class="row">
			  <div class="col-sm-6">
			  	<h1>Socialized With Social</h1>
			  	 <ul>
			  	 	<li><i class="fa-brands fa-facebook" style="height: 30; width: 30;"></i><a href="">facebook</a></li>
			  	 	<li><i class="fa-brands fa-instagram"></i><a href="">instagram</a></li>
			  	 	<li><i class="fa-brands fa-square-twitter"></i><a href="">twitter</a></li>
			  	 	<li><i class="fa-brands fa-linkedin"></i><a href="">linkedin</a></li>
			  	 </ul>
			  </div>

			  <div class="col-sm-6">
			  	<h1>Contact Us</h1>
			  	  <p><i class="fa-regular fa-envelope"></i> abc@gmail.com</p>
			  	  <p><i class="fa-solid fa-phone"></i> 123+ 234 2323424</p>
			  	  <p><i class="fa-solid fa-house"></i> Flat No: 23 XYZ</p>
			  </div>
		</div>
	</div>		
</footer>
<script src="require/user_functions.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>

function registration_pattern(){
  var flag = true;
   var first_name_value = document.getElementById('first_name').value;
   var first_name_element = document.getElementById('first_name');

    var last_name_value = document.getElementById('last_name').value;
    var last_name_element = document.getElementById('last_name');

    var email_value = document.getElementById('email').value;
    var email_element = document.getElementById('email');

   var password_value = document.getElementById('password').value;
   var password_element = document.getElementById('password');

   var gender = document.querySelector('input[type=radio]:checked');

    var date_of_birth_value = document.getElementById('date_of_birth').value;
    var date_of_birth_element = document.getElementById('date_of_birth');

   var address_value = document.getElementById('address').value;
   var address_element = document.getElementById('address');
   var formFile_value =   document.getElementById('formFile').value;
   var formFile_element = document.getElementById('formFile');


   var first_name_msg = document.getElementById('first_name_msg');
   var last_name_msg = document.getElementById('last_name_msg');
   var email_msg = document.getElementById('email_msg');
   var password_msg = document.getElementById('password_msg');
   var gender_msg = document.getElementById('gender_msg');
   var address_msg = document.getElementById('address_msg');
   var date_of_birth_msg = document.getElementById('date_of_birth_msg');
   var formFile_msg = document.getElementById('formFile_msg');
var name_pattern = /^[A-Z]{1}[a-z]{2,}$/;
var email_pattern = /^[a-z]{2,}\d{2,3}[@]{1}(gmail|hotmail|yahoo)[.](com|org|.net)$/;
var password_pattern = /^[A-Z]{1,}[a-z]{4,}[\W]{1}[\d]{2,3}$/; 

	if(first_name_value == ""){
       flag = false;
       first_name_msg.innerHTML = "Please Insert Record";
	}else{
        first_name_msg.innerHTML = "";
		  if(!(name_pattern.test(first_name_value)==true)){
		  	flag = false;
             first_name_msg.innerHTML = "first name must be like eg: Ali";
		  }
	}

	if(last_name_value == ""){
        flag = false;
        last_name_msg.innerHTML = "Please Insert Record";
	}else{
        last_name_msg.innerHTML = "";
		  if(!(name_pattern.test(last_name_value)==true)){
             flag = false;
             last_name_msg.innerHTML = "last name must be like eg: Gohar";
		  }
       }


    if(email_value == ""){
       flag = false;
       email_msg.innerHTML = "Please Insert Record";
    }else{
       email_msg.innerHTML = "";
    	 if(!(email_pattern.test(email_value)==true)){
             flag = false;
             email_msg.innerHTML = "email must be like eg: ahmed88@gmail.com";
    	 }
    }


    if(password_value == ""){
       flag = false;
       password_msg.innerHTML = "Please Insert Record";
    }else{
      password_msg.innerHTML = "";
    	 if(!(password_pattern.test(password_value)==true)){
             flag = false;
             password_msg.innerHTML = "password must be like eg: Sehwan.786";
    	 }
    }


    if(gender == null){
       flag = false;
       gender_msg.innerHTML = "Please Select Gender";
    }else{
       gender_msg.innerHTML = ""; 
    }


    if(date_of_birth_value == ""){
       flag = false;
       date_of_birth_msg.innerHTML = "Please Insert Record";
    }else{
       date_of_birth_msg.innerHTML = "";
    }

    if(address_value == ""){
       flag = false;
       address_msg.innerHTML = "Please Insert Record";
    }else{
       address_msg.innerHTML = "";
    }

    if(formFile_value == ""){
       flag = false;
       formFile_msg.innerHTML = "Please Insert Record";
    }else{
       formFile_msg.innerHTML = "";
    }


	if(flag === true){
          return true;
	}else{
         return false;
	}     

}           
</script>
<script src="client_side_validation.js"></script>	
<?php
 if(isset($_REQUEST['show_msg'])){
?>
<script>
     setTimeout(function(){
       document.getElementById('show_msg').style.display= 'none';
     },5000);
</script>
<?php
}
?>
</body>
</html>