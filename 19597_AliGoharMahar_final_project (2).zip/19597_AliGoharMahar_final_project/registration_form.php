<?php
include "require/header.php";
?>

<div class="container my-3">
	<div class="row">
	<div class="col-md-2"></div>
	<div class="col-md-8">
	<h1 class="text-center text-light bg-dark bg-gradient rounded">Registration Form
	</h1>
	   
      <?php

        if(isset($_REQUEST['show_msg'])){
          ?>
      <p id="show_msg" class="text-light rounded text-center" style="background-color: <?=$_REQUEST['bg_color']?>;"><?= $_REQUEST['show_msg']?></p>

        <?php 
        }elseif(isset($_REQUEST['msg'])){
      ?>
               <p id="show_msg" class="text-light rounded text-center" style="background-color: <?=$_REQUEST['bg_color']?>;"><?= $_REQUEST['msg']?></p>

        <?php 
      }
      ?>


	<form method="POST" action="database_file/process.php" enctype="multipart/form-data" onsubmit="return registration_pattern()">
		<div class="mb-3">
		    <label  class="form-label">First Name</label>
		    <input type="text" class="form-control" name="first_name" id="first_name" style="outline:<?= (isset($_SESSION['first_name_msg'])?'1px solid red':'')?>;">
		    <p id="first_name_msg" class="text-center text-danger"><?=$_SESSION['first_name_msg']??''?></p>
		</div>

		<div class="mb-3">
		    <label  class="form-label">Last Name</label>
		    <input type="text" class="form-control" name="last_name" id="last_name" style="outline:<?= (isset($_SESSION['last_name_msg'])?'1px solid red':'')?>;">
		    <p id="last_name_msg" class="text-center text-danger"><?=$_SESSION['last_name_msg']??''?></p>
		</div>

		<div class="mb-3">
		    <label  class="form-label">Email</label>
		    <input type="email" class="form-control" name="email" id="email" style="outline:<?= (isset($_SESSION['email_msg'])?'1px solid red':'')?>;">
		    <p id="email_msg" class="text-center text-danger"><?=$_SESSION['email_msg']??''?></p>
		</div>

		<div class="mb-3">
		    <label  class="form-label">Password</label>
		    <input type="password" class="form-control" name="password" id="password" style="outline:<?= (isset($_SESSION['password_msg'])?'1px solid red':'')?>;">
		    <p id="password_msg" class="text-center text-danger"><?=$_SESSION['password_msg']??''?></p>
		</div>

		<div class="mb-3">
		    <label class="form-label">Gender &nbsp;&nbsp;&nbsp;</label>
		    Male
		    <input class="form-check-input" type="radio" name="gender" value="Male" >
		    Female
		    <input class="form-check-input" type="radio" name="gender" value="Female">
		    <span id="gender_msg" class="text-center text-danger ml-5"><?=$_SESSION['gender_msg']??''?></span> 
		</div>

		<div class="mb-3">
		    <label  class="form-label">Date Of Birth</label>
		    <input type="date" class="form-control" name="date_of_birth" id="date_of_birth" style="outline:<?= (isset($_SESSION['date_of_birth_msg'])?'1px solid red':'')?>;">
            <p id="date_of_birth_msg" class="text-center text-danger"><?=$_SESSION['date_of_birth_msg']??''?></p>
		</div>


		<div class="mb-3">
		    <label for="exampleFormControlTextarea1" class="form-label">Address</label>
		    <textarea class="form-control"  rows="3" name="address" id="address" style="outline:<?= (isset($_SESSION['address_msg'])?'1px solid red':'')?>;"></textarea>
            <p id="address_msg" class="text-center text-danger"><?=$_SESSION['address_msg']??''?></p>
		</div>

		<div class="mb-3">
		    <label for="formFile" class="form-label">User Profile</label>
		    <input class="form-control" type="file" id="formFile" name="user_profile" style="outline:<?= (isset($_SESSION['formFile_msg'])?'1px solid red':'')?>;">
            <p id="formFile_msg" class="text-center text-danger"><?=$_SESSION['formFile_msg']??''?></p>
		</div>
		<input type="submit" name="user_register" class="bg-primary text-light rounded border border-none fs-5" value="Register">
	</form>
  </div>
  <div class="col-md-2"></div>
</div>
</div>



   
<?php
session_destroy();
 //if(isset($_REQUEST['user_register'])){
 //       $flag = true;

 //   extract($_REQUEST);

 //             $name_pattern = "/^[A-Z]{1}[a-z]{2,}$/";
 //  $email_pattern = "/^[A-Za-z]{1}\w{2,}[@]{1}(gmail|hotmail|yahoo)[.](com|org|.net)$/";

 // $password_pattern = "/^[A-Z]{1,}[a-z]{4,}[\W]{1}[\d]{2,3}$/"; 
  


 //        $first_name_msg = null; 
 //        $last_name_msg = null; 
 //        $email_msg = null; 
 //        $password_msg = null;  
 //        $gender_msg = null; 
 //        $date_of_birth_msg = null; 
 //        $address_msg = null;
 //        $formFile_msg = null;


 //        if($first_name == ""){
 //           $flag = false;
 //           $first_name_msg = "Field Required";
 //        }
 //        else{
 //           $first_name_msg = "";
           
 //           if(!(preg_match($name_pattern, $first_name)==true)){
 //           	$flag = false;
 //              $first_name_msg = "Pattern must be like eg: Ali";
 //           }
 //        }



 //        if($last_name == ""){
 //            	$flag = false;
 //              $last_name_msg = "Field Required";
 //            }else{
 //            	$last_name_msg = "";
 //            	if(!(preg_match($name_pattern, $last_name))){
 //            		$flag = false;
 //                   $last_name_msg = "Pattern must be like eg: Gohar";
 //            	}
 //            }

            
 //            if($email == ""){
 //            	$flag = false;
 //              $email_msg = "Field Required";
 //            }else{
 //            	$email_msg = "";
 //            	if(!(preg_match($email_pattern, $email))){
 //            		$flag = false;
 //                   $email_msg = "Pattern must be like eg: ahmed9@gmail.com | ahmed99@gmail.com";
 //            	}
 //            }



 //             if($phone_number == ""){
 //            	$flag = false;
 //              $phone_number_msg = "Field Required";
 //            }else{
 //            	$phone_number_msg = "";
 //            	if(!(preg_match($phone_number_pattern, $phone_number))){
 //            		$flag = false;
 //                   $phone_number_msg = "Pattern must be like eg: +92345-1234567";
 //            	}
 //            }


 //            if($cnic_number == ""){
 //            	$flag = false;
 //              $cnic_number_msg = "Field Required";
 //            }else{
 //            	$cnic_number_msg = "";
 //            	if(!(preg_match($cnic_number_pattern, $cnic_number))){
 //            		$flag = false;
 //                 $cnic_number_msg = "Pattern must be like eg: 12345-1234567-1";
 //            	}
 //            }


 //            if($about == ""){
 //            	$flag = false;
 //              $about_msg = "Field Required";
 //            }else{
 //            	$about_msg = "";
            	
 //            }


 //            if($country == ""){
 //               $flag = false;
 //               $country_msg = "Field Required";
 //            }else{
 //            	$country_msg = "";
 //            }

 //            if(!(isset($gender))){
 //                 $flag = false;
 //               $gender_msg = "Field Required";
 //            }else{
 //                $gender_msg = "";
 //            }
 //            $attendence = null;
 //            $assignment = null;
 //            $test = null;
 //            $stipend = null;
 //            if(!(isset($policies))){
 //                 $flag = false;
 //               $policies_msg = "Field Required"; 
 //            }else{
 //                $policies_msg = "";
 //                foreach ($policies as $key => $value) {
 //                	if ($value=="Attendence Policy") {
 //                		$attendence = "checked";
 //                	}
 //                	if ($value=="Assignment Policy") {
 //                		$assignment = "checked";
 //                	}
 //                	if ($value=="Test Policy") {
 //                		$test = "checked";
 //                	}
 //                	if ($value=="Stipend Policy") {
 //                		$stipend = "checked";
 //                	}
 //                }

 //                if(!(count($policies) === 4)){
 //                    $flag = false;
 //                    $policies_msg = "Please Select All";
 //                 }else{
 //                 	 $policies_msg = "";
 //                 }
 //            }
 // }
include "require/footer.php";
?>	   