<?php
session_start();
error_reporting(0);
if(isset($_SESSION['user'])){

  include "require/header.php";
  include "database_file/database_setting.php";
  include "database_file/database_driver.php";

  $obj = new database($hostname,$username,$password,$database);
  if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'see_more' ){
       extract($_REQUEST);
 
      
      $limit = 3;
      $page = $_GET['page']??1;
      $offset = ($page-1)*$limit;
      $query = "SELECT * FROM post WHERE post_status = 'Active' ORDER BY post_id DESC Limit {$offset},{$limit}";
      $execute = $obj->execute_query($query);

      if($execute->num_rows > 0){
?>
<div class="conatiner m-0 p-0" id="detail_page">
  <div class="row  my-3">
   <div class="col-md-3">
      <h3 class="text-decoration-underline">Latest Posts</h3>  
        <?php 
          while ($row = mysqli_fetch_assoc($execute)) {
           extract($row);
        ?>
      <div class="row">
        <div class="col-sm-12">
          <div class="card my-2">
            <img src="<?=$featured_image?>" class="card-img-top" alt="..." style="height: 150px;">
            <div class="card-body">
              <h5 class="card-title"><?=$post_title?></h5>
              <p class="card-text"><?=$post_summary?></p>
              <a href="detail_page.php?action=see_more&current_post_id=<?=$post_id?>" class="btn btn-primary">see more</a>
            </div>
          </div>
        </div>
      </div>
        <?php 
          }
           $count_post_query = "SELECT COUNT(post_id) 'total_post' FROM post WHERE post_status = 'Active'";
           $count_post_query_execute = $obj->execute_query($count_post_query);

           if($count_post_query_execute->num_rows > 0){
               $row = mysqli_fetch_assoc($count_post_query_execute);
               extract($row);

               $total_post_record = $total_post;
               $post_per_page = ceil($total_post_record/$limit);
        ?> 
              <nav aria-label="...">
              <ul class="pagination  pagination-lg">
        <?php
              for ($loop=1; $loop <= $post_per_page ; $loop++) { 
         ?>
             <li class="page-item"><a class="page-link" href="detail_page.php?page=<?=$loop?>&action=see_more&current_post_id=<?=$current_post_id?>"><?=$loop?></a></li>
         <?php     	
              }
         ?>
             </ul>
            </nav> 
        <?php      
           }
        ?> 
              
   </div>
        <?php 
          
          $query = "SELECT p.*,CONCAT(u.first_name,' ',u.last_name) 'full_name' FROM post p JOIN blog b  ON p.blog_id = b.blog_id INNER JOIN user u ON u.user_id = b.user_id  WHERE  p.post_id = '{$current_post_id}'";
	        $execute = $obj->execute_query($query);
          if($execute->num_rows > 0){
             $row = mysqli_fetch_assoc($execute);
             extract($row);
        ?> 
    <div class="col-md-8">
      <div class="card w-100" style="width: 18rem;">
		         <img src="<?=$featured_image?>" class="card-img-top" alt="..." style="height: 400px;">
	        <div class="card-body">
	        	 <div class="d-flex justify-content-between">
	        	 <p class="bg-success text-light rounded">Posted By: <?=$full_name?> </p>
	        	 <p class="text-end"><?=$created_at?></p>
	        	 </div>
		         <h5 class="card-title"><?=$post_title?></h5>
		         <p class="card-text"><?=$post_description?></p>
	        </div>
	    </div>
        <?php 
         if($is_comment_allowed == '1'){
         	?>
          <div class="card">					  
				    <div class="d-flex">  
	            <div class="card-body">
	              <form action="database_file/process.php" method="POST">
	               <div class="form-floating">
					         <textarea class="form-control" name="text_comment" placeholder="Leave a comment here" id="text_comment" required></textarea>
					         <label for="floatingTextarea">Comments</label>
					       </div>
					         <input type="hidden" name="current_post_id" value="<?=$current_post_id?>">
					         <button type="submit" name="send_comment" class="btn btn-primary my-2">Submit</button>
				        </form>
				      <?php 
         }
               if(isset($_REQUEST['total_comment']) && $_REQUEST['total_comment'] == 'show_comment'){
                $query = "SELECT * FROM post_comment pc JOIN user u ON u.user_id = pc.user_id WHERE pc.post_id = '{$current_post_id}' && pc.is_active = 'Active' ORDER BY post_comment_id DESC";
                $execute = $obj->execute_query($query);
                if($execute->num_rows > 0){
                	?>
                	<div class="border border-secondary rounded">
                  <?php    	
                	while($row = mysqli_fetch_assoc($execute)){
                     extract($row);
                  ?>
	                 <div>	
	            	    <img class="my-3 mx-1 rounded-pill" src="<?=$user_image?>" style="height: 50px; width: 50px;">
	            	    <span class="mx-5"><?=$comment?></span>
	            	    <p class="text-end"><?=$created_at?></p>
	                  </div>
                  <?php 
                  }
                  ?>
                  </div>
              <?php
                }
               }
				 ?>
					    </div>
					  </div>
					</div>              
    </div> 
  </div>
</div>       

<?php
  
    }
   } 
  }elseif(isset($_REQUEST['action']) && $_REQUEST['action'] == 'view_blog' ){
      
   extract($_REQUEST);
      $query = "SELECT * FROM blog b  JOIN user u on u.user_id = b.user_id WHERE b.blog_id = '{$current_blog_id}'";
      $execute = $obj->execute_query($query);
      if($execute->num_rows > 0){
       $row = mysqli_fetch_assoc($execute);
         extract($row);
      }
   ?>
		  <div class="container">
		  	<div class="row">
		  		<div class="col-sm-12 my-2">
		  		  <div class="row">
			  			<div class="col-sm-4"></div>
			  			<div class="col-sm-4 justify-content-center">
							  <div class="card">
									  <img src="<?=$blog_background_image?>" class="card-img-top" style="height: 180px;">
							    <div class="card-body">
									    <h5 class="card-title">Posted By: <span><?=$first_name." ".$last_name?></span><button style="float:right" type="button" class="btn btn-primary">Follow</button></h5>
									    <p class="card-text"><?=$blog_title?></p>
							    </div>
							  
				        </div>
				      </div>
			  			<div class="col-sm-4"></div>
		        </div>
		  		</div>
		  	</div>
		  	<div class="row">
		  		<div class="col-sm-12">
		  			  <h1 class="fw-bold"> Posts Related <?=$blog_title?> </h1>
		  		</div>
		  	</div>
		      <?php 
          $limit = $post_per_page;
           	$page = $_GET['page']??1;
           $offset = ($page - 1)*$post_per_page;
		      $query = "SELECT p.*,CONCAT(u.first_name,' ',u.last_name) 'full_name' FROM post p JOIN blog b ON b.blog_id = p.blog_id INNER JOIN user u ON b.user_id = u.user_id WHERE p.blog_id = '{$current_blog_id}' Limit {$offset},{$limit}";
		        $execute = $obj->execute_query($query);
		      if($execute->num_rows > 0){  
           ?>
		  	    <div class="row">
		  		  <?php 
		  		  while($row = mysqli_fetch_assoc($execute)){
		  		   	    extract($row);
		  		  ?>
		  		    <div class="col-sm-4">
		  			   	<div class="card">
									  <img src="<?=$featured_image?>" class="card-img-top" style="height: 180px;">
							    <div class="card-body">
							    	<div class="d-flex justify-content-between">
							    		<p class="bg-success text-light rounded">Posted By: <?=$full_name?></p>
							    		<p class="text-end"><?=$created_at?></p>
							    	</div>
									    <h5 class="card-title"><?=$post_title?></h5>
									    <p class="card-text"><?=$post_summary?></p>
							    </div>
							    <a href="detail_page.php?action=view_blog_post&current_blog_id=<?=$current_blog_id?>&current_post_id=<?=$post_id?>" class="btn btn-primary">see more</a>
							  </div>
		  		    </div>

		        <?php
		        } 
            ?>

             
            <?php
            $query = "SELECT COUNT(post_id) 'blog_posts' FROM post WHERE blog_id = {$current_blog_id} && post_status = 'Active'";
            $execute = $obj->execute_query($query);
            if($execute->num_rows > 0){
            	$row  = mysqli_fetch_assoc($execute);
              extract($row);
              echo $blog_posts;
              $total_blog_post = $blog_posts;
              $per_page = ceil($total_blog_post/$limit);
            ?>
            <nav aria-label="..." class="text-center">
            <ul class="pagination d-flex justify-content-center pagination-lg">
            <?php 
		          for($loop=1; $loop<=$per_page ; $loop++) { 
		        ?>
    <li class="page-item"><a class="page-link" href="detail_page.php?page=<?=$loop?>&action=view_blog&current_blog_id=<?=$current_blog_id?>"><?=$loop?></a></li>

		        <?php
		          } 
		        ?>
               </ul>
              </nav>
		        <?php
		        }
		  	    ?>

		  	    </div>
		  </div>
		     <?php
		      }
		    
  }elseif(isset($_REQUEST['action']) && $_REQUEST['action'] == 'view_blog_post'){
     extract($_REQUEST);
      ?>
     <div class="conatiner m-0 p-0" id="detail_page">
	    <div class="row  my-3">
              <?php 
               $query = "SELECT * FROM blog WHERE blog_id = {$current_blog_id}";
               $execute = $obj->execute_query($query);
               if($execute->num_rows > 0){
                 $row = mysqli_fetch_assoc($execute);
                 extract($row);
               }
              ?>
	        <div class="col-md-3">
	    	 <h3>Related Posts of Blog <?=$blog_title?></h3>
           <?php 
             $limit = $post_per_page;
             $page = $_GET['page']??1;
             $offset = ($page - 1)*$limit;

            $blog_post_query = "SELECT * FROM post WHERE blog_id = {$current_blog_id} Limit {$offset},{$limit}";
            $blog_post_query_execute = $obj->execute_query($blog_post_query);
            if($blog_post_query_execute->num_rows > 0){
             while ($row = mysqli_fetch_assoc($blog_post_query_execute)) {
             	   extract($row);
                  
                 $total_records = $blog_post_query_execute->num_rows; 
             	   $total_page = ceil($total_records / $limit);
            ?> 
	    	    <div class="col-sm-12">
	            <div class="card my-2">
					          <img src="<?=$featured_image?>" class="card-img-top" alt="..." style="height: 150px;">
					      <div class="card-body">
					          <h5 class="card-title"><?=$post_title?></h5>
					          <p class="card-text"><?=$post_summary?></p>
					        <a href="detail_page.php?action=view_blog_post&current_post_id=<?=$post_id?>&current_blog_id=<?=$current_blog_id?>" class="btn btn-primary">see more</a>
					      </div>
			        </div>
	          </div>
                  <nav aria-label="...">
                 <ul class="pagination pagination-lg">
            <?php 
                  for ($loop=1; $loop <= $total_page ; $loop++) { 
                 ?>
                <li class="page-item"><a class="page-link" href="detail_page.php?action=view_blog_post&page=<?=$loop?>&action=view_blog_post&current_blog_id=<?=$current_blog_id?>&current_post_id=<?=$current_post_id?>"><?=$loop?></a></li>                  
                 <?php 	 
                  }
              ?>
                  </nav>
                 </ul>

             <?php     
             }
            }else{
            ?>
	    	  <h3 class="text-decoration-underline">No Related Post</h3>
             <h3></h3>
            <?php
            }
            ?>
          

	        </div>
	    <?php
	    

	    $query = "SELECT p.*,CONCAT(u.first_name,' ',u.last_name) 'full_name' FROM post p JOIN blog b ON p.blog_id = b.blog_id INNER JOIN user u ON u.user_id = b.user_id  WHERE post_id = '{$current_post_id}'";
	    $execute = $obj->execute_query($query);

	    if($execute->num_rows > 0){

	      $row = mysqli_fetch_assoc($execute);
	      extract($row);

	    ?>    
  

	        <div class="col-md-8">
	          <div class="card w-100" style="width: 18rem;">
					     <img src="<?=$featured_image?>" class="card-img-top" alt="..." style="height: 400px;">
				      <div class="card-body">
				   	   <div class="d-flex justify-content-between">
				   		   <p class="bg-success text-light rounded">Posted By: <?=$full_name?></p>
				   		   <p class="text-end"><?=$created_at?></p>
				   	  </div>
					       <h5 class="card-title"><?=$post_title?></h5>
					       <p class="card-text"><?=$post_description?></p>
				      </div>
				    </div>
        <?php 
        if($is_comment_allowed == '1'){

         ?>

						<div class="card">					  
						 <div class="d-flex">  
		          <div class="card-body">
		           <form action="database_file/process.php" method="POST">
		            <div class="form-floating">
								  <textarea class="form-control" name="text_comment" placeholder="Leave a comment here" id="text_comment" required></textarea>
								  <label for="floatingTextarea">Comments</label>
								 </div>
								 <input type="hidden" name="current_post_id" value="<?=$current_post_id?>">
								 <button type="submit" name="send_comment" class="btn btn-primary my-2">Submit</button>
							 </form>
					 
				 <?php 
        }
             if(isset($_REQUEST['total_comment']) && $_REQUEST['total_comment'] == 'show_comment'){
                $query = "SELECT * FROM post_comment pc JOIN user u ON u.user_id = pc.user_id WHERE pc.post_id = '{$current_post_id}' && pc.is_active = 'Active' ORDER BY post_comment_id DESC";
                $execute = $obj->execute_query($query);
                if($execute->num_rows > 0){
                	?>
                  <div class="border border-secondary rounded">
                  <?php    	
                	while($row = mysqli_fetch_assoc($execute)){
                     extract($row);
                       ?>
                      <div>	
                      	<img class="my-3 mx-1 rounded-pill" src="database_file/<?=$user_image?>" style="height: 50px; width: 50px;">
                      	<span class="mx-5"><?=$comment?></span>
                      	<p class="text-end"><?=$created_at?></p>
                      </div>
                      <?php 
                	}
                  ?>
                  </div>
                <?php
                
               }
             }
					  ?>
					    </div>

             </div>
            </div>
          </div> 
         </div>
      </div>
           
   <?php

  }
}
include "require/footer.php";
}else{
    header("location: login_form.php?show_msg=Please Login First...!&bg_color=red");
}
?>