<?php 
session_start();

if(isset($_SESSION['user'])){

include "database_file/database_setting.php";
include "database_file/database_driver.php";

$obj = new database($hostname,$username,$password,$database);
   if(isset($_REQUEST['is_followed']) && $_REQUEST['is_followed'] == 'Followed'){
       extract($_REQUEST);
       $select_query = "SELECT * FROM following_blog WHERE follower_id = $user_id";
       $execute_1 = $obj->execute_query($select_query);

       if($execute_1->num_rows > 0){
         while($row = mysqli_fetch_assoc($execute_1)){
            extract($row);
            if($current_blog_id == $following_blog_id && $status == 'Followed'){

               $delete_query = "DELETE FROM following_blog WHERE follower_id = $user_id AND following_blog_id = $current_blog_id";
               $execute_2 = $obj->execute_query($delete_query);
            }
         }
       }

       $query = "INSERT INTO following_blog values(null,'{$user_id}','{$current_blog_id}','{$is_followed}',Now(),'null')";
       $execute = $obj->execute_query($query); 
       if($execute){
           header("location: index.php?is_followed=Followed&follower_blog_id=$current_blog_id&follower_user_id=$user_id#blog");
       }
    }elseif(isset($_REQUEST['is_followed']) && $_REQUEST['is_followed'] == 'Unfollowed'){
       extract($_REQUEST);
        

       $query = "DELETE FROM following_blog WHERE follower_id = '{$user_id}' && blog_following_id = '{$current_blog_id}'";
       $execute = $obj->execute_query($query); 

       if($execute){
           header("location: index.php?is_followed=Followed&current_blog_id=$current_blog_id&user_id=$user_id#blog");
       }

   }

}else{
    header("location: login_form.php?show_msg=Please Login First...!&bg_color=red");    
}
?>