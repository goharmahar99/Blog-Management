<?php
error_reporting(0);
class database{
	public $hostname;
	public $username;
	public $password;
	public $database;
	public $connection;
	public $query;
	public $execute;


	public function __construct($hostname,$username,$password,$database){
          $this->hostname = $hostname;
          $this->username = $username;
          $this->password = $password;
          $this->database = $database;

       $this->connection = mysqli_connect($this->hostname,$this->username,$this->password,$this->database);

       return $this->connection;
	}

	public function execute_query($query){
	     $this->query = $query;
       $this->execute = mysqli_query($this->connection,$this->query);

       return $this->execute;
	}
}



?>