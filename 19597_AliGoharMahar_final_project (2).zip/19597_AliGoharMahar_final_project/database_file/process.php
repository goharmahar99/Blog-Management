<?php
session_start();
include "database_setting.php";
include "database_driver.php";
$obj = new database($hostname,$username,$password,$database);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


require 'fpdf/fpdf.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';
$mail = new PHPMailer();
$fpdf = new FPDF();

//Tell PHPMailer to use SMTP

$mail->SMTPOptions = array(
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    )
);
// $mail->SMTPDebug = SMTP::DEBUG_SERVER;  
$mail->isSMTP();
// Enable SMTP debugging
// SMTP::DEBUG_OFF = off (for production use)
// SMTP::DEBUG_CLIENT = client messages
//SMTP::DEBUG_SERVER = client and server messages

// $mail->SMTPDebug = SMTP::DEBUG_SERVER;


$mail->Host = 'smtp.gmail.com';
$mail->Port = 587;
$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
$mail->SMTPAuth = true;
$mail->Username = 'agmahar11@gmail.com';
$mail->Password = 'eohtkioqnbdlubxl';
if(isset($_REQUEST['user_register'])){
 extract($_REQUEST);
   $flag = true;

   $name_pattern = "/[A-Z]{1}[a-z]{2,}$/";
   $email_pattern = "/^['a-z']{2,}\d{2,3}[@]{1}(gmail|hotmail|yahoo)[.](com|org|.net)$/";

   $password_pattern = "/^[A-Z]{1,}[a-z]{4,}[\W]{1}[\d]{2,3}$/"; 
    $image_pattern = "/^image/";


        $_SESSION['first_name_msg'] = null; 
        $_SESSION['last_name_msg'] = null; 
        $_SESSION['email_msg'] = null; 
        $_SESSION['password_msg'] = null;  
        $_SESSION['gender_msg'] = null; 
        $_SESSION['date_of_birth_msg'] = null; 
        $_SESSION['address_msg'] = null;
        $_SESSION['formFile_msg'] = null;


            if($first_name == ""){
               $flag = false;
               $_SESSION['first_name_msg'] = "Please Insert Record";
            }else{
           
               if(!(preg_match($name_pattern, $first_name))){
                $flag = false;
                  $_SESSION['first_name_msg'] = "first name must be like eg: Ali";
               }
            }



            if($last_name == ""){
               $flag = false;
              $_SESSION['last_name_msg'] = "Please Insert Record";
            }else{
               if(!(preg_match($name_pattern, $last_name))){
                  $flag = false;
                   $_SESSION['last_name_msg'] = "last name must be like eg: Gohar";
               }
            }

            
            if($email == ""){
               $flag = false;
              $_SESSION['email_msg'] = "Please Insert  Record";
            }else{
               if(!(preg_match($email_pattern, $email))){
                  $flag = false;
                   $_SESSION['email_msg'] = "email must be like eg: ahmed88@gmail.com";
               }
            }



            if($password == ""){
               $flag = false;
              $_SESSION['password_msg'] = "Please Insert Record";
            }else{
               if(!(preg_match($password_pattern, $password))){
                  $flag = false;
                   $_SESSION['password_msg'] = "password must be like eg: Sehwan.786";
               }
            }


            if(!(isset($gender))){
               $flag = false;
               $_SESSION['gender_msg'] = "Please Insert Record";
            }


            if($date_of_birth == ""){
               $flag = false;
              $_SESSION['date_of_birth_msg'] = "Please Insert Record";
            }


            if($address == "" || $address ==  " "){
               $flag = false;
               $_SESSION['address_msg'] = "Please Insert Record";
            }

            if($_FILES['user_profile']['name'] == ""){
               $flag = false;
               $_SESSION['formFile_msg'] = "Please Insert Record";
            }else{
               if($_FILES['user_profile']['size'] > 1000000){
                  $flag = false;
                 $_SESSION['formFile_msg'] = "file size not greater than 1 mb";
               }
               if(!(preg_match($image_pattern, $_FILES['user_profile']['type']))){
                  $flag = false;
                  $_SESSION['formFile_msg'] = "file must be image type";

               }
            }

            
            
 
   if($flag){

    $dir = "../images";

      if(!(is_dir($dir))){
         if(!(mkdir($dir))){
            echo "Dir is not created";
         }
      }

      $file_name = rand()."_".$_FILES['user_profile']['name'];
      $file_tmp_name = $_FILES['user_profile']['tmp_name'];
      $file_path = "images/user_image/".$file_name;
    if(move_uploaded_file($file_tmp_name,"../".$file_path)){
      $query = "INSERT INTO user values('null',2,'{$first_name}','{$last_name}','{$email}','{$password}','{$gender}','{$date_of_birth}','{$file_path}','{$address}','Pending','InActive',Now(),'null')";

      $execute =  $obj->execute_query($query);
      if($execute){
        $fpdf->AddPage();
        $fpdf->SetFillColor(100, 150, 150);
        $fpdf->SetFont("Arial", "B", 30);
        $fpdf->setTextColor(50,200,200);
        $fpdf->Cell(0, 12, "User Information", "0", 2, "C");
        $fpdf->setFont("Arial", "b", 14);
        $fpdf->Cell(0, 12, "First Name :".$first_name, "0", 2, "");
        $fpdf->Cell(0, 12, "Last Name :".$last_name, "0", 2, "");
      $fpdf->Cell(0, 12, "Email :".$email, "0", 2, "");
      $fpdf->Cell(0, 12, "Password :".$password, "0", 2, "");
      $fpdf->Cell(0, 12, "Address :".$address, "0", 2, "");
      $fpdf->Cell(0, 12, "Gender : ".$gender, "0", 2, "");
      $fpdf->Cell(0, 12, "Date of birth :" . $date_of_birth, "0", 2, "");

      $email_path = "../user_record/".$first_name."_".$last_name.".pdf";
      $fpdf->Output('F', $email_path);

      $mail->setFrom('agmahar11@gmail.com', 'Mr Abc');
      $mail->addReplyTo('agmahar11@gmail.com', 'Mr Abc');
      $mail->addAddress($email, $first_name.' '.$last_name);
      $mail->Subject = 'User Registration';
      $mail->isHTML(true);
      $mail->Body = "<b style='color:red;'>Mr: '".$first_name.' '.$last_name."' Thank You For Your Registration</b>";
      // $mail->send();
        //$execute_2 = $obj->execute_query($query_2);
      $mail->addAttachment($email_path);

         $query = "SELECT * FROM user WHERE role_id = 1";
         $execute = $obj->execute_query($query);
         if($execute->num_rows > 0){
          while($row = mysqli_fetch_assoc($execute)){
              extract($row);
           $mail->addAddress($email, $first_name.' '.$last_name);
           $mail->Subject = 'New User Registration';

          }
         }
       if (!$mail->send()) {
         echo 'Mailer Error: ' . $mail->ErrorInfo;
       } else {

      header("location: ../registration_form.php?show_msg=Thank You For Your Registration&bg_color=green");      
      }
      
      }else{
      	echo "Record Not Inserted";
      }
    } 
   }else{
       header("location:../registration_form.php");
   }   
	
}elseif(isset($_REQUEST['admin_register'])){
   extract($_REQUEST);
   $dir = "../images";

      if(!(is_dir($dir))){
         if(!(mkdir($dir))){
            echo "Dir is not created";
         }
      }

      $file_name = rand()."_".$_FILES['user_profile']['name'];
      $file_tmp_name = $_FILES['user_profile']['tmp_name'];
      $file_path = "images/user_image/".$file_name;
        move_uploaded_file($file_tmp_name,"../$file_path");

   $query = "INSERT INTO user values('null',$role_type,'{$first_name}','{$last_name}','{$email}','{$password}','{$gender}','{$date_of_birth}','{$file_path}','{$address}','pending','In_active',Now(),'null')";

      $execute =  $obj->execute_query($query);
      if($execute){
        header("location: ../admin/admin_dashboard.php?msg=User Registered...!&color=green");
          die();
      }else{
      	echo "Record Not Inserted";
      } 
}elseif(isset($_REQUEST['login'])){
   extract($_REQUEST);
   $query = "SELECT * FROM user WHERE email = '{$email}' && password = '{$password}'";
   $execute = $obj->execute_query($query);
         $row = mysqli_fetch_assoc($execute);
          if($row['role_id'] == 1){
               if($row['is_approved'] == 'Approved'){
                  if($row['is_active']){
                     $_SESSION['user'] = $row;
                      header("location: ../admin/admin_dashboard.php");

                  }else{
                     header("location: ../login_form.php?show_msg= Please Contact with Admin&bg_color=red");
                  }
               }else{
                  header("location: ../login_form.php?show_msg= Your Request is on Pending&bg_color=red");
               }
          }

          elseif($row['role_id'] == 2){
               if($row['is_approved'] == 'Approved'){
                  if($row['is_active']=='Active'){
                     $_SESSION['user'] = $row;
                    header("location: ../index.php");
                  }else{
                     header("location: ../login_form.php?show_msg=Your account is in_active please contact with admin&bg_color=red");
                  }
               }else{
                  header("location: ../login_form.php?show_msg= Your Request is on Pending&bg_color=red");
               }
          }

          else{
            header("location: ../login_form.php?show_msg=Invalid Username/Password...!&bg_color=red");
          }
}elseif(isset($_REQUEST['send_comment'])){
      extract($_REQUEST);
      $text_comment = htmlspecialchars($text_comment);
      $query = "INSERT INTO post_comment values('null','{$current_post_id}','{$_SESSION['user']['user_id']}','{$text_comment}','Active',Now())";

      $execute = $obj->execute_query($query);

      if($execute){
           header("location: ../detail_page.php?action=see_more&total_comment=show_comment&current_post_id=$current_post_id");
      }else{
         echo "Comment Not Added";
      }
}elseif(isset($_REQUEST['action']) && $_REQUEST['action'] == 'in_active_comment'){
        extract($_REQUEST);
      $query = "UPDATE post_comment SET is_active = 'InActive' WHERE post_comment_id = '{$comment_id}'";
      $execute = $obj->execute_query($query);
      if($execute){
        header("location: ../admin/show_comment.php");
      }

}elseif(isset($_REQUEST['action']) && $_REQUEST['action'] == 'active_comment'){
        extract($_REQUEST);
      $query = "UPDATE post_comment SET is_active = 'Active' WHERE post_comment_id = '{$comment_id}'";
      $execute = $obj->execute_query($query);
      if($execute){
        header("location: ../admin/show_comment.php");
      }

}elseif(isset($_REQUEST['send_feedback'])){

   $fullname  = $_REQUEST['full_name']??$_SESSION['user']['first_name']." ".$_SESSION['user']['last_name'];
   $email = $_REQUEST['email']??$_SESSION['user']['email'];

   $feedback = htmlspecialchars($_REQUEST['feedback']);

        $user_id = $_SESSION['user']['user_id'];
         echo $user_id;
     if(isset($_SESSION['user'])){
         $query = "INSERT INTO user_feedback (user_id,user_name,user_email,feedback) values('{$user_id}','{$fullname}','{$email}','{$feedback}')";
     }else{
          $query = "INSERT INTO user_feedback (user_id,user_name,user_email,feedback) values(null,'{$fullname}','{$email}','{$feedback}')";
     }
     
     
     $execute =$obj->execute_query($query);
     if($execute){
      header("location: ../index.php");

     }
}elseif(isset($_REQUEST['edit_user_profile'])){

           extract($_REQUEST);
           $dir = "../images";
           if(!(is_dir($dir))){
            if(!(mkdir($dir))){
                echo "$dir folder is not created";
            }
           }

           $file_name = rand()."_".$_FILES['user_profile']['name'];
           $file_tmp_name = $_FILES['user_profile']['tmp_name'];
         
           $file_path = "images/user_image/".$file_name;
           move_uploaded_file($file_tmp_name,"../".$file_path);

           if($_FILES['user_profile']['name'] == ""){
             $profile_img = $previous_image;
           }else{
            $profile_img = $file_path;
           }

           $query = "UPDATE user SET first_name = '{$first_name}',last_name = '{$last_name}',email = '{$email}',password = '{$password}',gender = '{$gender}',date_of_birth = '{$date_of_birth}',user_image = '{$profile_img}', updated_at = Now() WHERE user_id = '{$_SESSION['user']['user_id']}'";
          
            $execute = $obj->execute_query($query);

            if($execute){
               if($_SESSION['user']['role_id'] == 1){
                  header("location: ../admin/admin_dashboard.php");                
               }else{
              header("location: ../index.php");
               }
            }
}elseif(isset($_REQUEST['forget_password'])) {
          extract($_REQUEST); 
         
      if($password == $confirm_password){

         $query = "UPDATE user SET password = '{$password}' WHERE email = '{$email}'";
         $execute = $obj->execute_query($query);

         if($execute){
             header("location: ../forget_password.php?msg=Password Changed Successfully&color=green");
         }else{
            header("location: ../forget_password.php?msg=Email not matched...!&color=red");
         }
      }else{
        
        header("location: ../forget_password.php?msg=Password not matched...!&color=red");
      }

     
}
   


?>