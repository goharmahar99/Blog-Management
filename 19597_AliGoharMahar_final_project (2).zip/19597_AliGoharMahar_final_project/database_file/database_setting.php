<?php
$hostname = "localhost";
$username = "root";
$password = "";
$database = "19597_ali_gohar_mahar";
?>